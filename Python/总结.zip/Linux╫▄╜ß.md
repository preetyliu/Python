计算机：软件、硬件
硬件五部分:运算器、控制器、存储器、输入设备、输出设备
中央处理器CPU：运算器+控制器
软件：系统软件、应用软件
管理硬件提供人机界面
Unix -->Minix(不能用，教学用的) -->Linux
Linux的发行版本：CentOS / Redhat / Ubuntu / SUSELinux
SSH客户端-->XShell
shell --> bash

远程连接：
>telnet
>SSH:安全连接

## CentOS安装python3步骤：
1.. 安装GCC及依赖库：
​        yum -y install  gcc zlib-devel bzip2-devel openssl-devel ncurses-devel sqlite-devel readline-devel tk-devel gdbm-devel db4-devel libpcap-devel xz-devel
2. 从官方网站下载Python源代码: wget  https://www.python.org/ftp/python/3.6.5/Python-3.6.5.tar.xz 
3. 解压缩：xz -d Python-3.6.5rc1.tar.xz
4. 解归档：tar -xvf  Python-3.6.5rc1.tar
5. 配置安装信息（生成构建文件Makefile）:
    ​    cd Python-3.6.5
    ​    ./configure --prefix=/usr/local/python36/ --enable-optimizations
6. 执行构建和安装：make && make install
7. 配置PATH环境变量：   
    ​    cd ~  
    ​    vim .bash_profile  
    ​    PATH=$PATH:/usr/local/python36/bin
    ​    source .bash_profile
    ​    echo $PATH
8. 创建符号链接：ln -s /usr/local/python36/bin/python3 /usr/bin/python3

跟新pip：python3 -m pip install -U pip

## Linux常用命令

    clear:清空当前窗口
    who/w:查询连接的用户
    last:列出目前与过去登入系统的用户相关信息
    who am i:查询连接的用户中的自己
    logout / exit:退出登录
    whatis 命令:查询命令的作用
    whereis 命令:查询命令的位置
    Tab键:补全，提示
    man 命令:查询命令的手册
    wget:非交互式网络下载器
    adduser 用户名：添加新的用户名
    userdel:删除用户
    passwd 用户名：创建新用户的密码
    pwd:打印工作主目录
    ls:查看主目录下的文件
    ls -la/l/a 目录:查看目录下所有的文件(包括隐藏文件)
    ls -la ： 查看当前目录下的所有文件(包括隐藏文件)
    (cat -n 文件名 | more/less)   / (more/less 文件名) :分屏显示
    cat 文件名:查看文件内容
    命令 --help:查看命令相关的使用帮助 
    命令 --help | grep 关键词:查看命令相关的使用帮助中与关键词相关的内容
    rm 文件名:删除文件
    rm -f:强制删除
    rm -r:递归式删除
    rm -i:交互式删除
    head -数量 文件名：查看文件中前几行的内容
    tail -数量 文件名：查看文件中后几行的内容
    mkdir 文件夹名：创建文件夹
    mkdir -p 文件夹名1/文件夹名2：创建一个文件夹1，文件夹1中在创建一个文件夹2
    rmdir:删除空文件夹 
    touch 文件名:创建文件
    reboot / init 6 :重启服务器
    shutdown / init 0:关闭
    shutdown -c：取消关机
    ps -aux / ef (|grep 需要查看的进程)：查看所有进程状态(指定查看的进程)
    netstat -nap (|grep 需要查看的进程): 查看网络端口和状态(指定查看的进程)
    systemctl start mysqld：启动进程
    systemctl enable mysqld：开机自启
    systemctl disable mysqld：取消开机自启
    kill 端口号：终止进程
    history:查看历史命令(! 编号：可以执行这个编号的历史命令)
    history -c:清除历史命令
    cd:改变目录
    file 文件:查看文件属性
    cp ... :拷贝文件或者文件夹
    mv ... :移动文件或者文件夹
    find+路径+查找的属性+属性：根据属性查找文件
    grep 字符串：搜索文件里面的字符串
    gzip 文件名：压缩
    gunzip 文件名:解压缩
    tar -xvf 文件名:解归档
    tar -cvf 文件名: 归档
    xz -d/-z 文件名：解压缩/压缩
    wc+参数+文件名:统计指定文件中的字节数、字数、行数，并将统计结果显示输出(-c 统计字节数、-l 统计行数)
    alias 新名='命令'：设置一个新别名与命令作用相同
    unalias 新名：取消新别名
    recover：恢复意外中断的文件
    chmod+参数+文件：修改文件的访问权限（参数：u/g/o  +/-  r/w/x）
    ln -s 绝对路径...：软链接
    uniq:去重
    sort：排序
    命令 >/>> 文件名：输出/追加输出重订项
    2> / 2>>:错误输出 / 追加输出重订项
    <:输入重订项
    diff 文件名1 文件名2：比较两个文件有什么不同
    ln 绝对路径:硬链接
    文本编辑器：vim/vi (命令模式-编辑模式-末行模式)
    vim -d 文件名1 文件名2..:比较多个文件的不同
    切换光标：按两下Ctrl+w
    paste:合并两个文件
    cut -b 参数 文件：剪切某一段文件（参数：num-num）
    ifconfig:查看IP地址
    top：查看CPU利用率
    su 其他用户:切换用户
    chown 用户 文件：把文件转让给其它用户
    jobs：查看在后台运行的程序
    ctrl+z：把程序放到后台，放进去是停止的
    bg %+编号 ：后台运行
    fg %+编号 ：前台运行
    启动命令 &:把程序放到后台执行
    crontab -e：计划表
    计划表达式：分、时、日、月、周（不设值用*表示==>可以在etc目录下的crontab文件中直接写）
    ls | xargs rpm -ivm:把前一个数的输出作为后一个数的参数
    netstat -lntp:查看所有端口的情况
    tail -f 日志文件：查看日志文件（一直看最后一行）
    nohup 命令：后台运行


用长格式(-l)查看文件时：
>第一个符号
    -:文件
    l:软链接
    d:文件夹
>后面的符号：
    r:读
    w:写
    x:执行
可以看做二进制；改权限可以把二进制转换成十进制当做参数
    rwx : 111(看做二进制)
    r-x : 101
    1-- : 100
    chmod 755 myCal.py 
    -rwxr-xr-x 1 root root 96 Jul 25 10:51 myCal.py

# 快捷键：
​    Ctrl c：终止程序的执行
​    Ctrl z：暂停执行，还可以恢复
​    Ctrl y:往上走一行
​    Ctrl e：往下走一行
​    Ctrl b：往上走一页
​    Ctrl f：往下走一页
​    yy p:复制
​    dd：删除
​    G：最后一行
​    行数 G：到哪行
​    gg：到第一行

# 格式
​    命令[参数...][目标]
shell -交互式环境(本身也是一个程序)
bash - bourne again shell（默认的shell）

# 其它
Linux下建立的快捷方式叫软链接或者叫符号链接

>Web服务器：nginx
>nginx -s reload:重启服务器
>nginx -s stop:停止服务器
>sftp 身份名@服务器公网号：服务器之间互传文件
>scp 本地文件名 @服务器公网号：需要拷贝到的对方文件地址：拷贝本地文件到对方服务器中
>get 文件名：下载文件
>put 文件名：上传文件

# Linux安装软件的方式：
1.包管理工具：

>yum
>   yum install 软件名：安装软件
>   yum search 软件名：查找软件
>   yum remove 软件名：卸载软件
>   yum info 软件名：查看软件信息
>   yum list installed:查询历史安装
>rpm
>   rpm -ivh <rpm-file-name>：安装
>   rpm -e <rpm-file-name>:移除
>   rpm -qa：查询
>
>apt-get
>   sudo apt-get uninstall 软件名:卸载软件
>   sudo apt-get install 软件名：安装软件
>2.二进制安装程序
>3.下载解压归档免安装(通常要配置环境变量才能使用)
>4.源代码构建安装

# Git
在Windows下使用git
​    git init ===> 初始化Git仓库
​    git add ===> 放到暂存区
​    git status ===> 查看暂存区状态
​    git commit -m '...' ===> 提交到仓库
​    git log ===> 查看版本前的提交日志
​    git reflog ===> 查看所有的提交日志
​    git reset --hard 哈希码(前5/6/7)===> 重置到指定版本
​    git clone 项目地址===> 从远端克隆项目到本地
​    git push (-u) origin master ===> 从本地推到服务器(本地文件建立关联时，推送到远端第一次需要加-u属性)
​    git pull ===> 从服务器更新代码
​    git checkout -- 文件名：把暂存区的文件内容拿出来覆盖工作区文件的内容
​    git rm --cached 文件名：撤回暂存区的文件
​    git remote add origin 远端的url：让本地与远端服务器的仓库建立关联
​    git branch (分支名)==>查看分支(添加分支)
​    git checkout 分支名 ==> 切换到分支
​    git branch -d/D 分支名==> 删除/强制删除分支（删除必须在合并之后，如果没有合并必须强制删除；都要切换到master中在删除）
​    git checkout -b 分支名：切换到分支，如果分支没有就新建分支并切换到新建分支
​    git+merge+ 分支名：如果要在master上面合并分支，需要先切换回master然后用

github上传文件用法

```
1、创建一个库
2、创建一个文件夹，在文件夹中git init  -->可以不用执行这个命令
3、git clone 项目地址
4、把要添加的文件放入克隆后下载下来的文件夹中
5、git add . ("." ：把文件夹中的所有文件放入暂存区)
6、git config --global user.email "123145255@qq.com"
7、git config --global user.name "lzl"
8、git commit -m '...' (“...”:随便写什么，是上传过后对文件的描述)
9、git push 需要提交到的url master(或者分支名)
```

# 版本控制

版本控制方式： Github-flow， Git-flow

```
git clone 地址：克隆项目
git pull：从服务器跟新
git branch：查看分支
git branch 文件名：创建分支
git checkout 分支名： 切换分支
git checkout -b 分支名：切换到分支，如果分支没有就新建分支并切换到新建分支
git add 文件名：将文件从工作区放到暂存区
git checkout -- 文件名：用暂存区的文件覆盖工作区文件
git reset HEAD 文件名：将文件从暂存区移除
git commit -m '提交信息'：将暂存区的内容提交到本地仓库

git log：查看提交日志(当前版本及以下版本)
git reflog：查看日志(可以查看之前到现在所有的版本)
git reset HEAD ：回到上一个版本
git reset id: 回到ID指定的版本
git reset --hard id：回到ID指定的历史版本并让工作区和指定版本保持一致
git branch -d/D 分支名==> 删除/强制删除分支（删除必须在合并之后，如果没有合并必须强制删除；都要切换到master中在删除）

git push origin 分支名：提交到分支上面
```
# 缺陷管理/问题管理

Redmine / 禅道


# 加密算法

> 对称加密：aes
> 分对称加密：rsa
