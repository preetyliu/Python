#一、Web介绍
标签(Tag) - 数据
层叠样式表(CSS) - 显示
    选择器
    盒子模型
JavaScript(JS) - 行为
    ECMAScript - ES5 - 核心语言(语法规范)
    BOM - 浏览器对象模型
    DOM - 文档对象模型

CSS要前置

JS要后置，一般放在后面
三元条件运算符格式：条件？true执行语句:false执行语句
转化为整数：parseInt()
转化为小数：parsefloat()

#二、7.16
##浏览器属性
浏览器的函数都可以不用写前面的window. : alert()、prompt()...
在浏览器中弹出警示框：window.alert()
在浏览器弹出输入框:window.prompt()
在浏览器弹出确认框：window.confirm()
更改浏览器地址栏:location.href = "地址"
计时器(周期更新)：window.setInterval ( 执行的函数名,  间隔时间(单位是毫秒) )
计时器(将来某个时间只跟新一次)：setTimeout ( 执行的函数名, 多久时间后执行(单位是毫秒) )
清除计时器：clearInterval(id)、clerTimeout(id)

##获取html标签
获取html中的id对象内容：var  变量 = document.getElementById("id名")
##修改html标签内容
修改对象文本内容：获取的变量.textContent = 新内容
修改对象标签内容: 获取的变量.innerHTML = 新内容

##生成随机数
随机生成一个0-1的数(不包括1)： Math.random()
随机生成一个0-100的整数：parseInt(Math.random() * 100 + 1)

##for循环
例如：for(var i=1;i<10;i+=1){执行的程序}

for (变量  in  对象){执行的语句} : 这个循环取出的是对象的所有属性，不是取出的容器内容
遍历一般也用for循环来写，而不是用for in 

##while循环
while(条件){执行的程序}
#三、 7.17
##函数的一些运用
声明函数的关键词：function 函数名(参数){函数执行的代码}。

arguments是函数默认的属性。
没有函数名时(匿名函数等):可以用arguments.callee代表函数本身。
自调用函数：(funtion(){})()、+funtion(){}()

##绑定点击事件
如果希望点击按钮时会执行对应的操作，那么需要通过JS为按钮绑定事件回调函数。绑定为回调函数大致有3种方式：
    1.通过标签的onXXX属性来指定需要执行的函数。    
    2.在JS代码中通过元素的onXXX属性来绑定事件回调函数。
    3.通过元素的addEventListener方法来绑定事件回调函数。

通过document对象获取页面上的元素(标签)有以下方法（推荐使用5和6）：
    1.document.getElementById("...")
    2.document.getElementByTagName("...")
    3.document.getElementBYClassName("...")
    4.document.getElementByName("...")
    5.document.querySelector("...")
    6.document.querySelectorAll("...")

鼠标事件监听：获取内容存的变量.addEventListener("事件",执行的函数) / 获取内容存的量.attachEvent("on事件",执行的函数)
鼠标移除时间监听：removeEventListener / detachEvent
获取事件源(谁引发了事件)：evt.target / evt.srcElement

通过元素获取相关节点的属性
parentNode:获取父节点
    evt.target.parentNode.index;
children:获取所有子节点
    ul.children;
nextSibling:获取相邻下一个兄弟节点
previousSibing:获取相邻上一个兄弟节点
    ul.nextSibling;
    ul.previousSibing

#四、7.18

在前面添加标签：父节点.insertBefore(位置，添加的标签)
在后面添加标签：父节点.appendChild(添加的标签)

创建节点：
    var li = document.createElement("li");
    li.textContent = fruitName;
添加子节点：
    var ul = document.querySelector("#fruits");
    ul.appendChild(li);
通过父节点删除子节点：li.parentNode.removeChild(li)

键盘事件：keyup、keydown...
判断按下的键：
    var code = evt.keyCode || evt.which;
    if(code == 13){
        addItem();
    }

#五、7.19
阻止事件冒泡：
    evt.stopPropagation();  // 停止事件传播(阻止事件冒泡)

读样式表：
    var divStyle= document.defaultView.getComputedStyle(div)
    var top = divStyle.top

访问jquery第三方库的网站：https://www.bootcdn.cn/
CDN：内容分发网络

写Javascript代码是为什么推荐使用jQuery而不是写原生Javascript，因为jQuery对象有更多的属性和方法，能够用更少的代码做更多的事情，而且jQuery对象的方法没有浏览器兼容问题

当加载jQuery成功时会在window对象上绑定名为jQuery的属性，该属性还有一个名字叫$.
jquery中的\$函数： $既是一个对象也是一个函数
当$作为函数时有以下四种最常用的用法：
>1、如果  $  函数的参数是一个函数 ，传入的函数是页面加载完成时要执行的回调函数
>2、如果\$函数的参数是选择器字符串，那么$ 函数会返回代表元素的jQuery对象(其本质是一个数组)
>3、如果\$函数的参数是标签字符串，那么​$ 函数会创建该标签，并返回对应的jQuery对象
>4、如果\$函数的参数是原生Javascript对象(DOM)，那么$函数会将该对象处理成jQuery对象

#7.20

jQuery可以用网上CDN地址：<script src="https://cdn.bootcss.com/jquery/1.12.4/jquery.min.js"></script>

筛选器：
> odd:奇数       \$("#date tr:odd")
> even：偶数      \$("#date tr:even")
> eq(多少行)：等于   \$("#date tr:eq(0)")
> gt(多少行)：大于   \$("#date tr:gt(0)")

筛选器可以叠加： \$("#date tr:gt(0):last")

Ajax - 异步JavaScript和XML
Asynchronous   JavScript   and   XML
浏览器在后台向服务器发出异步请求
"异步请求"：在后台执行不中断用户体验
服务器向浏览器返回新的数据(XML)
XML文件要声明：<xml  version="1,0"  encoding="utf-8"? >
XML:是早年间异构系统之间交换数据的事实标准
在不中断用户体验的情况下从服务器获取数据并对页面进行"局部刷新"--为用户提供更好的体验

JSON -- JavaScript  Object  Notation
端口：用来区分服务
url：统一资源定位符  (协议://IP地址或域名:端口号/路径/资源?查询字符串)
HTTP(S)协议的请求有多种请求命令,浏览器在正常情况下只能发出get或者post请求；将来我们在项目中可能要用到的http请求命令包括以下5个：
>GET : 从服务器获取资源
>POST：向服务器提交资源
>DELETE：从服务器删除资源
>PUT / PATCH：跟新服务器上的资源

CDN：内容分发网络（其基本思路是尽可能避开互联网上有可能影响数据传输速度和稳定性的瓶颈和环节，使内容传输的更快、更稳定。通过在网络各处放置节点服务器所构成的在现有的互联网基础之上的一层智能虚拟网络，CDN系统能够实时地根据网络流量和各节点的连接、负载状况以及到用户的距离和响应时间等综合信息将用户的请求重新导向离用户最近的服务节点上。其目的是使用户可就近取得所需内容，解决 Internet网络拥挤的状况，提高用户访问网站的响应速度。）

不传错：冗余校验码
不传丢：握手机制（客户端要连接服务器的时候，首先要向服务器发出申请，这是第一次握手，服务器准备好了会向客户端发出一个响应，这是第二次握手，客户端得到响应后需向服务器发出一个回应，这是第三次握手，三次握手完成了，客户端和服务器才算建立了连接。）
拥塞控制：数据往返时间
滑动窗口协议
CDN
端口：用来区分服务
url：统一资源定位符

同源策略：用JS取数据时一般只能取本网站的数据
