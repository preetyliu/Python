### django中sendcload发送邮件

QQ邮箱和163邮箱发多了容易被封

settings.py文件中
```
# SendCloud邮件发送
def email(request):
    url = "http://api.sendcloud.net/apiv2/mail/send"

    # 您需要登录SendCloud创建API_USER，使用API_USER和API_KEY才可以进行邮件的发送。
    params = {"apiUser": "lzllalala_test_BiktJq ",
              "apiKey": "RFaCIfWhYwqjb1WZ",
              "from": "service@sendcloud.im",
              "fromName": "啦啦啦",
              "to": "1315908135@qq.com",
              "subject": "测试邮件",
              "html": "和嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯嗯"}
    requests.post(url, files={}, data=params)
    return HttpResponse('发送成功')
```
给这个方法写个路由就行了

###  POP3/SMTP服务密码
umjadpfshqwtghce

### IMAP/SMTP服务密码
joxstdchdrqyhdif

### 授权码
gudfmvlucqscbaeb

### django中QQ邮箱的发送方法

发送者邮箱开启```POP3/SMTP服务```和```IMAP/SMTP服务 ```,然后生成授权码

![设置位置](http://lzlimgs.oss-cn-shenzhen.aliyuncs.com/imgs/%E6%B7%B1%E5%BA%A6%E6%88%AA%E5%9B%BE_%E9%80%89%E6%8B%A9%E5%8C%BA%E5%9F%9F_20181016110423.png?Expires=1539917511&OSSAccessKeyId=TMP.AQFfVZtgOrXtfPd-Gsnt1vcV6P63FEmYL7ogwH7EgzAvw8Ni7LT4vgrpStpOADAtAhRmgJxfPteENmYPDAp7KCkoOhnGqgIVAKzUJxPQ3lJFI6gXjQz0By1lCDoZ&Signature=ezpt4XhwJps0DwU1iq5L3S7mo%2FI%3D)

![设置位置](http://lzlimgs.oss-cn-shenzhen.aliyuncs.com/imgs/%E6%B7%B1%E5%BA%A6%E6%88%AA%E5%9B%BE_%E9%80%89%E6%8B%A9%E5%8C%BA%E5%9F%9F_20181016112542.png?Expires=1539917840&OSSAccessKeyId=TMP.AQFfVZtgOrXtfPd-Gsnt1vcV6P63FEmYL7ogwH7EgzAvw8Ni7LT4vgrpStpOADAtAhRmgJxfPteENmYPDAp7KCkoOhnGqgIVAKzUJxPQ3lJFI6gXjQz0By1lCDoZ&Signature=9IRJTVG8I8esb5pItANzEp2x8qI%3D)


setting.py文件中

```
EMAIL_HOST = 'smtp.qq.com'
EMAIL_PORT = 25
EMAIL_HOST_USER = '1315908135@qq.com'  # 你的 QQ 账号
EMAIL_HOST_PASSWORD = 'gudfmvlucqscbaeb'  # QQ邮箱中生成的授权码，不是QQ密码
EMAIL_USE_TLS = True   # 这里必须是 True，否则发送不成功
EMAIL_FROM = '1315908135@qq.com'  # 你的 QQ 账号
```

views.py文件中
send_mail(邮件标题，邮件内容， 发送者邮箱， 对方的邮箱列表，参数 )
对方的邮箱可以有多个，全部写到列表中(['852555845@qq.com', '1163714024@qq.com'])

```
# 发送邮件
def email_ce(request):
    if request.method == 'GET':
        try:
            send_mail('测试邮件', '哈哈哈哈哈哈哈哈哈哈哈哈', '1315908135@qq.com', ['852555845@qq.com'], fail_silently=True)
            return HttpResponse('发送成功')
        except:
            return HttpResponse('发送失败')
```

urls.py文件中添加路由，访问这个方法就可以了

### 163邮箱的发送方法

注册163邮箱， 登录后设置---》POP3/SMTP/IMAP   中打开开发者模式 客户端的授权码‘

就settings.py配置不一样

```
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_USE_TLS = False   #是否使用TLS安全传输协议(用于在两个通信应用程序之间提供保密性和数据完整性。)
EMAIL_USE_SSL = True    #是否使用SSL加密，qq企业邮箱要求使用
EMAIL_HOST = 'smtp.163.com'   #发送邮件的邮箱 的 SMTP服务器，这里用了163邮箱
EMAIL_PORT = 25     #发件箱的SMTP服务器端口
EMAIL_HOST_USER = 'charleschen@xmdaren.com'    #发送邮件的邮箱地址
EMAIL_HOST_PASSWORD = '*********'         #发送邮件的邮箱密码(这里使用的是授权码)
```