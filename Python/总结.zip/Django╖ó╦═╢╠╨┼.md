### 互亿无线短信发送

先在验证码通知短信中下载API接口

下载完成后解压下载的文件夹，进入DEMO文件夹，进入python文件夹中，把文件夹中的文件内容复制到views.py文件中修改一些参数后，在urls.py中定义路由就可以使用了(不过这个网站发送的短信开头是互亿无线的名字)

views.py文件中

```
import http.client
import urllib

host = "106.ihuyi.com"
sms_send_uri = "/webservice/sms.php?method=Submit"

account = "C47426856"   #用户名在短信平台可拷贝
password = "cabb3049c50dfff19cb5b537e66603cc" #密码在短信平台可拷贝


def send_sms(text, mobile):
    params = urllib.parse.urlencode({'account': account, 'password': password, 'content': text, 'mobile':mobile,'format':'json' })
    headers = {"Content-type": "application/x-www-form-urlencoded", "Accept": "text/plain"}
    conn = http.client.HTTPConnection(host, port=80, timeout=30)
    conn.request("POST", sms_send_uri, params, headers)
    response = conn.getresponse()
    response_str = response.read()
    conn.close()
    return response_str


def duan_xin(request):
    if request.method == 'GET':
        mobile = "18011405897"
        text = "您的验证码是：520520。请不要把验证码泄露给其他人。"  # 这个是验证码模板，只能改验证码数字，不能改其他的
        send_sms(text, mobile)
        return HttpResponse("短信已发送")
```

urls.py文件中

```
url(r'^duan_xin/', views.duan_xin, name='duan_xin'),
```

### 阿里云短信发送

###### 步骤1：
　　在阿里云 “短信服务” 中创建一个签名
###### 步骤2：
　　在阿里云 “短信服务” 中创建一个短信模板
###### 步骤3：　　
　下载阿里云 “短信服务” SDK
###### 步骤4：
在虚拟工作环境中安装SDK：
  1> 进入SDK根目录(就是进入dysms_python文件夹)
  2> 在虚拟环境中执行命令：python3 setup.py install（如果有多个版本的python，最好是指定python的版本）

###### 步骤5：
　1> 在阿里云 “短信服务” 中得到：<ACCESS_KEY_ID> 与 <ACCESS_KEY_SECRET>
　2> 在const.py 文件中修改：<ACCESS_KEY_ID> 与 <ACCESS_KEY_SECRET>
###### 步骤6：
测试：
  1> 在 demo_sms_send.py 文件中修改 (模板CODE号可以在控制台找到)
```
if __name__ == '__main__':
    __business_id = uuid.uuid1()
    # 修改params参数，留着code验证码就行
    params = {"code":"314655"}
# id：固定的，接收验证码的手机号，签名名称，模板名称，验证码
    print(send_sms(__business_id, "要发送的手机号码", "模板名称", "模板code号", params))
```
  2> 运行SDK中的Dome：python demo_sms_send.py，运行成功就会收到短信
```
运行成功的提示
b'{"Message":"OK","RequestId":"FB9DA042-BC49-48F6-B429-62DEBE816C1C","BizId":"353701139853062948^0","Code":"OK"}'
```
如果运行不成功，可以根据Code参数到官方文档中查找(https://help.aliyun.com/document_detail/55491.html?spm=a2c4g.11186623.2.40.47042e791m7c0k)

###### 步骤7：
使用SDK：
>1 将阿里云SDK中的 “aliyunsdkdysmsapi” 文件夹复制到 django 项目中
>2 将阿里云SDK中的 “demo_sms_send.py” 文件复制到 django 项目中
此时如果导入的aliyunsdkcore报红,则说明该虚拟环境中需要安装sdk
```
pip3 install aliyun-python-sdk-core-v3

如果还不行在试试： pip3 install aliyunsdkdysmsapi
```

删除导入的const, 把const.py中的内容复制到文件中，把``` acs_client = AcsClient(const.ACCESS_KEY_ID, const.ACCESS_KEY_SECRET, REGION)```修改为:```acs_client = AcsClient(ACCESS_KEY_ID, ACCESS_KEY_SECRET, REGION) ```注释掉一部分代码```try和except```部分的代码，注释掉```if __name__ == '__main__':```,用一个函数调用```send_sms函数```



修改后的代码为：

```
# -*- coding: utf-8 -*-
import sys
from aliyunsdkdysmsapi.request.v20170525 import SendSmsRequest
from aliyunsdkdysmsapi.request.v20170525 import QuerySendDetailsRequest
from aliyunsdkcore.client import AcsClient
import uuid
from aliyunsdkcore.profile import region_provider
from aliyunsdkcore.http import method_type as MT
from aliyunsdkcore.http import format_type as FT

"""
短信业务调用接口示例，版本号：v20170525

Created on 2017-06-12

"""
# try:
#     reload(sys)
#     sys.setdefaultencoding('utf8')
# except NameError:
#     pass
# except Exception as err:
#     raise err

# 注意：不要更改
REGION = "cn-hangzhou"
PRODUCT_NAME = "Dysmsapi"
DOMAIN = "dysmsapi.aliyuncs.com"

ACCESS_KEY_ID = "LTAIVYYcKZ1tO0wc"
ACCESS_KEY_SECRET = "th4xyAheggzA2p6nsI5lJw8S2OVyRq"

acs_client = AcsClient(ACCESS_KEY_ID, ACCESS_KEY_SECRET, REGION)
region_provider.add_endpoint(PRODUCT_NAME, REGION, DOMAIN)


def send_sms(business_id, phone_numbers, sign_name, template_code, template_param=None):
    smsRequest = SendSmsRequest.SendSmsRequest()
    # 申请的短信模板编码,必填
    smsRequest.set_TemplateCode(template_code)

    # 短信模板变量参数
    if template_param is not None:
        smsRequest.set_TemplateParam(template_param)

    # 设置业务请求流水号，必填。
    smsRequest.set_OutId(business_id)

    # 短信签名
    smsRequest.set_SignName(sign_name)

    # 数据提交方式
    # smsRequest.set_method(MT.POST)

    # 数据提交格式
    # smsRequest.set_accept_format(FT.JSON)

    # 短信发送的号码列表，必填。
    smsRequest.set_PhoneNumbers(phone_numbers)

    # 调用短信发送接口，返回json
    smsResponse = acs_client.do_action_with_exception(smsRequest)

    # TODO 业务处理

    return smsResponse


def lala():
    __business_id = uuid.uuid1()
    # print(__business_id)
    params = {"code": "505205"}
    # params = u'{"name":"wqb","code":"12345678","address":"bz","phone":"13000000000"}'
    print(send_sms(__business_id, "18011405897", "lzlblogs", "SMS_148083251", params))
```

在views.py文件中，导入该模块的执行函数```lala()```

```
def a_li(request):
    if request.method == 'GET':
        lala()
        return HttpResponse('发送成功')
```
在urls.py中添加路由就可以使用了