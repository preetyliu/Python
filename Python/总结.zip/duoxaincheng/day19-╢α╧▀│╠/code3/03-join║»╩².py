"""__author__ = 余婷"""
from threading import Thread
import time


# 写代码，计算1~n(n>1000000)的和（在子线程中完成）
class Sum(Thread):
    """线程类--计算大数据的和"""
    def __init__(self, n):
        super().__init__()
        self.n = n
        self.result = None

    def run(self):
        time.sleep(3)
        sum1 = 0
        for x in range(1, self.n+1):
            sum1 += x
        self.result = sum1


if __name__ == '__main__':
    t1 = Sum(10000000)
    t1.start()
    print('======')

    # 在t1线程的任务执行完成后才去执行，后面的代码
    # 注意：join会阻塞线程，如果想要在一个子线程中的代码执行完后才执行的代码，要放到当前线程的最后面
    t1.join()
    print(t1.result)


