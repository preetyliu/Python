"""__author__ = 余婷"""
import socket

client = socket.socket()
client.connect(('10.7.154.82', 12346))

while True:
    # 发送消息
    send_message = input('>>>')
    client.send(send_message.encode('utf-8'))
    if send_message == '拜拜':
        client.close()
        break

    # 接受消息
    message_data = client.recv(1024)
    message = message_data.decode('utf-8')
    print(message)
    if message == '拜拜':
        client.close()
        break
