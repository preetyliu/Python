"""__author__ = 余婷"""
# import threading
from threading import Thread
import time


# 方式二：
# 1. 声明一个类，继承自Thread类
class DownloadThread(Thread):

    # 5.重写init方法来接收，run中需要的外部的内容
    def __init__(self, file):
        # 必须调用父类的init方法
        super().__init__()
        self.file = file

    # 2.重写run方法（run方法中的代码就是在子线程中执行的代码）
    def run(self):
        print('这句话是在子线程中打印的')
        print('开始下载%s' % self.file)
        time.sleep(5)
        print('%s下载完成' % self.file)

if __name__ == '__main__':

    # 3.通过Thread的子类去创建对象
    t1 = DownloadThread('aa.mp4')

    # 4.调用start方法，执行子线程中的任务(不能直接调用run方法)
    # t1.run()  # 直接调用run(),run中的代码是在当前线程中执行的
    t1.start()  # 通过start间接调用run,run中的代码是在新的线程中执行
    print('=======')

    # 创建了一个线程，去下载火影忍者100.mp4
    t2 = DownloadThread('火影忍者100.mp4')
    t2.start()






