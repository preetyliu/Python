"""__author__ = 余婷"""
# 每个python程序，在运行的时候，系统都为默认为这个进程创建一个线程来执行程序(这个线程叫'主线程')
# 如果想要让程序不在主线程中执行，就需要手动的去创建其他的线程('子线程') ---> threading模块(python内置的模块)

# time模块是python内置的时间相关的模块，里面提供了很多时间相关的类和方法
import time
import threading


def download(file):
    print('开始下载%s...' % file)
    time.sleep(5)
    print('%s下载完成，耗时5秒' % file)



if __name__ == '__main__':
    # ====在主线程中下载两个内容====
    # 获取当前时间
    # start = time.time()
    # download('一人之下.mp4')
    # download('海贼王.mov')
    # end = time.time()
    # print('总共耗时:%d秒'% (end-start))

    # 1.创建线程对象
    """
    target: 需要在当前创建的子线程中执行函数(函数变量)
    args: 给需要在子线程中执行的函数的参数(元祖) --->注意，实参后必须加逗号
    """
    t1 = threading.Thread(target=download, args=('一人之下.mp4',))

    # 2.执行需要在子线程中执行的代码
    t1.start()

    t2 = threading.Thread(target=download, args=('海贼王.mov',))
    t2.start()

    print('=======')



