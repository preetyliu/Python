"""__author__ = 余婷"""

"""
一个银行账号，可以通过银行柜台存取钱、可以通过支付宝存取钱、可以通过微信存取钱....
存钱：拿到余额数量 ---耗时---->余额数+存进去的数量---->将最新的余额存进系统

！！！多个线程同时对一个数据进行读写操作，可能会出现数据错乱的问题--->解决方案：加锁

"""

from threading import Thread, Lock, RLock
import time

class Account:
    def __init__(self, balance):
        self.name = ''
        self.user_id = ''
        self.balance = balance
        # 1.给数据加锁
        self.lock = Lock()


class SaveMoneyThread(Thread):
    def __init__(self, account, count):
        super().__init__()
        self.account = account
        self.count = count

    def run(self):
        # 在数据读出来到写进去之间加锁
        # 2.获取锁（加锁）
        self.account.lock.acquire()
        # 取出余额
        money = self.account.balance
        # 等待一段时间
        time.sleep(1)
        # 将钱存进入
        self.account.balance = money + self.count
        # 3.释放锁(解锁)
        self.account.lock.release()
        print('=====')


if __name__ == '__main__':
    account = Account(1000)
    account.name = '余婷'

    # 通过10个子线程，对同一个数据进行操作
    threads = []
    for _ in range(10):
        t = SaveMoneyThread(account, 100)
        t.start()
        threads.append(t)

    for t in threads:
        t.join()

    # time.sleep(10)

    print(account.balance)




















