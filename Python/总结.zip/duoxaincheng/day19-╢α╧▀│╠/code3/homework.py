"""__author__ = 余婷"""
import socket
import re
import requests

# 写一个两个人的聊天系统，可以实现双向聊天功能。
# # 如果发送的是普通的文字就直接打印，如果发送的文字是’拜拜’就关闭连接，
# # 如果是一个网络地址就获取数据，如果是图片地址就下载图片到本地

# 1. 创建服务器对应的套接字对象
server = socket.socket()

# 2. 绑定地址
server.bind(('10.7.154.82', 12346))

# 3. 监听连接
server.listen()


# 4.通过循环让服务器处于启动状态
while True:
    print('开始监听....')
    # 接受请求，（这句代码会阻塞线程，直到有请求为止）
    # 返回值是一个元祖，（连接，请求服务器的客户端的地址）
    contanct, addr = server.accept()

    while True:
        # 1.接受信息
        message_data = contanct.recv(1024)
        message = message_data.decode('utf-8')
        print(message)

        # 处理接受到的消息
        if message == '拜拜':
            # 关闭连接
            contanct.close()
            # 进入下一次等待
            break
        if re.match(r'https?://\S+\.(jpg)|(png)|(jpeg)|(gif)\s*$', message):
            print('是图片')
            url = re.search(r'https?://\S+\.(jpg)|(png)|(jpeg)|(gif)', message).group()
            response = requests.get(url)
            with open('aa'+re.search(r'.[a-zA-Z]+$', url).group(), 'bw') as f:
                f.write(response.content)




        # 2.发送信息
        send_message = input('>>>')
        contanct.send(send_message.encode('utf-8'))
        if send_message == '拜拜':
            # 关闭连接
            contanct.close()
            # 进入下一次等待
            break









