"""__author__ = 余婷"""
import threading
from random import randint
import time

class DownloadThread(threading.Thread):
    def __init__(self, file):
        super().__init__()
        self.file = file

    def run(self):
        print('开始下载 %s...' % self.file)
        download_time = randint(5, 10)
        time.sleep(download_time)
        print('%s下载完成,用时%d秒' % (self.file, download_time))


def main():
    start_time = time.time()
    thread1 = DownloadThread('后来的我们.mp4')

    thread1.start()

    thread2 = DownloadThread('摔跤吧爸爸.mov')
    thread2.start()
    thread1.join()
    thread2.join()
    end_time = time.time()
    print('总耗时:%d秒' % (end_time - start_time))


if __name__ == '__main__':
    main()