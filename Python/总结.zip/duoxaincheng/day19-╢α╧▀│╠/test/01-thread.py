"""__author__ = 余婷"""
import time
import threading
from random import randint

def download(file):
    print('开始下载 %s...'%file)
    download_time = randint(5, 10)
    time.sleep(download_time)
    print('%s下载完成,用时%d秒'%(file, download_time))


def main():
    # 不使用多线程
    # start_time = time.time()
    # download('一人之下1.mp4')
    # download('海贼王800.MP4')
    # end_time = time.time()
    # print('总耗时:%d秒' % (end_time - start_time))

    start_time = time.time()
    thread1 = threading.Thread(target=download, args=('一人之下1.MP4',))
    thread1.start()
    thread2 = threading.Thread(target=download, args=('海贼王.mp4',))
    thread2.start()
    end_time = time.time()
    print('总耗时:%d秒' % (end_time - start_time))

if __name__ == '__main__':
    main()
