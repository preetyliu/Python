"""__author__ = 余婷"""

import threading
import time

class Account:
    def __init__(self):
        self.money = 0
        self.lock = threading.Lock()

    def add_money(self, count):
        self.lock.acquire()
        money = self.money
        time.sleep(1)
        self.money = money+count
        self.lock.release()

class AddThread(threading.Thread):
    def __init__(self, account):
        super().__init__()
        self.account = account

    def run(self):
        self.account.add_money(1)

if __name__ == '__main__':
    account = Account()
    threads = []

    for _ in range(100):
        t = AddThread(account)
        threads.append(t)
        t.start()

    for t in threads:
        t.join()
    print(account.money)