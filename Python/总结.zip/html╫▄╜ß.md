#一、认识网页开发
##1.w3c(万维网)标准
* w3c对web开发制定的标准：
 >内容标准 - html 
 >结构标准 - css
 >行为标准 - javascript（js）
##2.html
>a.什么是html（就像markdown语法）
* html叫超文本标记语言（超文本，除了文本还可以显示其它的内容，包括：图片、视频、音频、输入框等）
* html是标记语言，不是编程语言
>b.html版本
* htnl1.0 - html2.0 - html3.2 -...- html5
* html5:狭义概念，html标记语言的第五个大版本；广义的html5指html5+css3+js
>c.html结构
* 网页的内容可以看成一个树结构
        <html>
        	<head>
        		负责网页中看不到的设置性的东西(灵魂)
        	</head>
        	<body>
        		负责网页所有显示的内容(树干)
        	</body>
        </html>
>d.html标记(标签、元素)
>>1)常规标记
*  <标记 属性=属性值 属性=属性值>内容</标记>
>>2)空标记
*  <标记 属性=属性值 属性=属性值 />
*  <标记 属性=属性值>
*  说明：
>1.尖括号中的第一个单词叫标记，标记后加一个空格后面的是属性，属性和属性值之间用等号连接，多个属性之间用空格隔开。
>2.属性之间没有先后顺序
>3.常规标记的开始标记和结束标记中间就是标记的内容，这个内容理论上可以是任何内容（包括任何文字或者任何标签）
>4.空标记只有属性
>5.不同的标记有不同的功能(给网页提供不同的内容)
#二、html主题结构
* 下面的结构，是每次写一个网页都必须写的结构
>DOCTYPE用来声明html版本：html 对应的是 html5
>注意：标签不区分大小写（DOCTYPE和doctype/Doctype是一样的）
        <!DOCTYPE html>
>html标签就是网页的根标签，所有的网页内容(不管看得见的还是看不见的)都要写在html标签中
        <html>
>head标签中主要是用来对网页进行设置和说明的(这个标签中的内容在网页上是看不见的)
>主要包含：title标签、type标签、script标签、meta标签、link、base等
        <head>
        	<!-- 设置网页的标题 -->
        	<title>python1804</title>
        	<!--charset:编码方式 -->
        	<meta charset="utf-8">
        </head>
>body标签代表网页上可见的部分，所有需要展示在网页上的内容都需要写在这个标签里
>包含p、h1-h6、div、table、input等
        <body>
            hello world
        </body>
        </html>
#三、文本标签
>1.标题标签（h1-h6）
* 功能：显示标题
* 注意：我们网页内容中的标题都要使用h标签
        <h1><h1/>
>2.段落标签（p标签）
* 在网页上单纯的显示一段文字（文字不是标题、没有特殊功能（比如点击会有跳转效果等等））
* 功能：p标签的内容结束后会默认换行，并且和下面的内容之间会多一个空行(一般情况一段文字使用一个P标签)
* 注意：html中的文本手动的插入换行、空格和制表符是无效的
        <p><p/>
>3.空格(&nbsp;)
        <p>&nbsp;你好<p/>
>4.加粗标签(b标签)
        <b><b/>
>5.strong标签
* 注意：显示效果上b标签和strong标签都有对文字进行加粗的效果，但是strong标签具有强调的意思，b标签没有
        <strong><strong/>
>6.i标签和em标签
* 让文字倾斜的标签,em标签有强调的意思
        <i><i/>
        <em><em/>
>7.强制换行标签（br标签）
        <br/>
>8.水平线(hr标签)
        <hr/>
#四、列表标签
##1.无序列表(ul标签)
    <ul>
    	<li>Python</li>
    	<li>H5</li>
    <ul/>
##2.有序列表(ol标签)
    <ol>
    	<li>Python</li>
    	<li>H5</li>
    <ol/>
##3.自定义列表(dl标签)
* dl中一组数据是通过dt和dd来列举的，dt后列举内容，dd后面对内容进行解释
        <dl>
        	<dt>Python</dt>
        	<dd>H5</dd>
        <dl/>
#五、图片和超链接
##1.图片标签(img标签)
* 注意：属性的值全部需要使用双引号括起来
>a. src:需要显示的图片的地址(本地和网页)
>本地图片：一般需要将图片放到当前的工程目录下
>b. alt:图片加载错误的提示信息
>c. title:鼠标放在图片上不动的时候弹出的提示信息
        <img id="001" src="./imgs/aa.gif" alt="图片加载错误的提示信息" title="标题">
##2.超链接标签(a标签)
* <a href="跳转目标地址">能够有点击跳转效果的内容</a>
* href:点击a标签跳转的目标地址
* target:有_self(默认)和_blank两个值。_self代表在当前页面打开href属性的内容，_blank代表在新的页面打开href属性的内容。
        <a href="http://www.baidu.com" target="_blank">百度一下</a>
        <a href="04-列表标签.html">点击一下</a>
        <a href="#001">回到顶部</a>
#六、表格标签
##1.标签
    table:表
    tr:行
    td:列
##2.属性
* border：设置表格边框的宽度

* bordercolor:设置表格边框的颜色，颜色值有两种表示方式(1.RGB的十六进制值,#xxxxxx; 2.颜色单词)

* width:表格宽度

* height:表格的高度(作为table的属性是设置整个表格的高度，作为tr的属性是设置当前行的高度)

* bgcolor:设置背景颜色(作为table属性设置整个表的背景颜色；作为tr属性设置当前行的背景颜色；作为td属性，设置这个具体的单元格的背景颜色)

* cellspacing:设置单元格与单元格之间的间隙(默认值是1)

* cellpadding:设置上下左右的间距;这儿要注意当表格本身的大小小于设置完间距后的内容的大小，表格会被撑大

* align:水品对齐方式（left、center、right）

        <table border="3" bordercolor="#ff0000" width="400" height="200" bgcolor="#f0fff0" cellspacing="0">
        	<tr bgcolor="#f00ff0">
        		<td bgcolor="000fff">姓名</td>
        	</tr>
        </table>
##3.合并表格
* rowspan:行合并
* colspan：列合并
* rowspan和colspan是td标签的属性，属性的值表示合并的列和合并的行的数量
        <table border="1" bgcolor="#f0fff0" width="400" height="200" cellspacing="0">
        	<tr>
        		<td rowspan="2"></td>
        		<td colspan="2"></td>
        		<td rowspan="2"></td>
        	</tr>
        	<tr>
        		<td></td>
         		<td></td>
         	</tr>
         </table>

