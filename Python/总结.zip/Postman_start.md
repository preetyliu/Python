### Postman启动步骤

1、进入Postman文件夹

```
/home/liuzhilong/Downloads/Postman/Postman
```

2、运行Postman文件

```
./Postman
```