#一、表单
##1.表单标签(form)
* 表单标签是用来收集在这个标签内的信息
* name:区分不同的表单
* method:表单中信息的提交方式，一般使用get和post。（和HTTP协议中的get/post是一个意思）
        <form name="userInfo" method="get/post" action="">
##2.input标签
* 注意：input标签是单标签
* 说明：input标签不一定非得放到form标签中，只有input标签中的value需要提交的时候才放到form标签中
* type:不同的值对应不同的效果(text、password等)
* name:区分不同的信息(是看不见的)
* value:具体的值(需要提交的内容)
* placeholder:占位符
>文本输入框
* value就是输入框中输入的内容 
* placeholder在input作为文本输入框时才有用
* maxlength:设置输入框能输入的最多的字符的个数
        <input type="text" name="username" value="用户名" placeholder="请输入用户名">
>密码输入框
        <input type="password" name="password" value="123456" placeholder="请输入密码" maxlength="8">
>单选按钮
>>a. name属性必须设置，并且同一组选项的name的值必须一样 
>>b. 设置value属性用于提交信息
>>c. checked属性的值设置为checked让按钮处于选中状态
        <input type="radio" name="sex" value="boy" checked="checked"/><span>男</span>
        <input type="radio" name="sex" value="girl"/><span>女</span>
>复选框
>>a. name属性必须设置，并且同一组选项的name的值必须一样 
>>b. 设置value属性用于提交信息
>>c. checked属性的值设置为checked让按钮处于选中状态
        <input type="checkbox" name="interest" value="PingPANG" checked="checked" /><span>乒乓球</span>
        <input type="checkbox" name="interest" value="basketball" /><span>篮球</span>
        <input type="checkbox" name="interest" value="football" /><span>足球</span>
        <input type="checkbox" name="interest" value="badminton" /><span>羽毛球</span>
>普通按钮
        <input type="button" value="登录">
>图片提交按钮
        <input type="image" name="" src="./img/图标.jpg" width="40" height="30">
>文件域
        <input type="file" name="icom">
>提交按钮
* 将表单中的内容以name=value的形式进行提交，提交到form标签中的antion属性对应的地址下面
        <input type="submit">
>重置按钮
* 对所在的表单中的内容进行重置(回到最初的状态)
        <input type="reset">
##3.select标签(下拉菜单)
* selected:通过设置属性值为selected，设置默认选项
        <select name="loction">
        	<option>四川省</option>
        	<option>山东省</option>
        	<option>辽宁省</option>
        	<option selected="selected">广东省</option>
         	<option>黑龙江省</option>
        </select>
##4.多行文本框(textarea)
>a.常规标签
>b.输入框里面的内容，在标签的内容中设置
>c. rows:设置一屏能看到最多的行数
>d. cols:设置列数
    <textarea name="yijian" cols="40" rows="10">意见</textarea>
##5.div
* div标签是一个无语义的标签，主要是用来对网页的内容进行分块管理，是块标签
##6.span标签
* 文本结点：需要在一些特定的标签后显示一些说明文字的时候使用
#二、CSS基础
* 选择符的作用：获取需要设置样式的标签对象  
* CSS的选择符有十几种，包括：属性(元素)选择符、id选择符、class选择符、通配符、群组选择符、包含选择符、伪类选择符等
##1.元素选择符
* 直接将标签名作为选择符，样式表会作用于当前页面中所有同名的标签
        p{color: red;
        	font-size: 30px;
        }
##2.id选择符：#id值
* 所有的标签都有一个id属性,不同的标签对应的id属性值要唯一
        p{color: red;
        	font-size: 30px;
        }
##3.class选择器：.class值
* 所有的标签都有一个class属性，多个标签可以有相同的class值
        .userInfo{font-size: 30px;}
##4.通配符
* 选中网页界面上所有的标签
        *{background-color: #000fff;}
##5.群组选择符
* 通过逗号将不同的单选择符连接在一起作为选择符。同时选中所有用逗号分开的选择符
        h1,#p1,.test{background-color: #f00ff0;}
##6.包含选择器
* 通过空格将不同的单选择符连接在一起作为选择符
* 通过前面的选择符依次往后面查找被包含的选择符，直到找到最后一层为止，最后一层的选择符才是最终被选中的标签
        div div p{color: red}
		div .test{color: #f0f0f0}
##7.伪类选择符
* 语法：  选择符:固定的状态{属性:属性值;属性:属性值}
* 固定的状态:link、visited、hover、active
* 伪类选择符一般用来给标记的不同的状态设置不一样的样式，一般用于a标签和按钮标签(button);语法上所有标签都适用
  >a:link{}-初始状态
  >a:visited{}-访问后的状态
  >a:hover{}-鼠标悬停的时候的状态
  >a:active{}-鼠标按住不放的状态
* 伪对象选择符:和伪类选择符差不多，唯一的区别就是冒号前面不是指向所有相同类型的标签，而是某一个标签。
* 伪类(对象)选择符需要遵守爱恨原则(LoVe HAte):在同时设置多个状态的样式的时候，设置的先后顺序必须按照LoVeHAte的先后顺序来
* 去掉下划线：text-decoration: none;