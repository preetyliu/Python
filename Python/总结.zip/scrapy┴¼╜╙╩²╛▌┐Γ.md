### 存入Mongodb

```
class MyPiplinesMongo(object):
    def __init__(self, database, coll):
        self.database = database
        self.post = pymongo.MongoClient()[database][coll]

    @classmethod
    def from_crawler(cls, crawler):
        return cls(
            database=crawler.settings.get("MONGO_DB"),
            coll=crawler.settings.get("MONGO_COLL"),
        )

    def process_item(self, item, spider):
        dict1 = {'title': item["title"], 'leixin': item['leixin'], 'cover': item["cover"]}
        self.post.insert(dict1)
        return item
```

### 存入mysql

```
class MyPiplines(object):
    def __init__(self, host, user, password, port, database):
        self.host = host
        self.database = database
        self.port = port
        self.user = user
        self.password = password

    @classmethod
    def from_crawler(cls, crawler):
        return cls(
            host=crawler.settings.get("MYSQL_HOST"),
            database=crawler.settings.get("MYSQL_DATABASE"),
            user=crawler.settings.get("MYSQL_USER"),
            password=crawler.settings.get("MYSQL_PASSWORD"),
            port=crawler.settings.get("MYSQL_PORT"),
        )

    def open_spider(self, spider):
        self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8', port=self.port)
        self.cursor = self.db.cursor()

    def close_spider(self, spider):
        self.db.close()

    def process_item(self, item, spider):
        sql = "insert into manhua (title, leixin, cover) values ('%s', '%s', '%s')" % (item['title'], item['leixin'], item['cover'])
        # print(sql)
        self.cursor.execute(sql)
        self.db.commit()
        return item
```

### 用sqlalchemy存入mysql数据库

modles.py文件

```
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, ForeignKey, UniqueConstraint, Index
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy import create_engine

engine = create_engine("mysql+pymysql://root:123456@127.0.0.1:3306/yaoqi?charset=utf8", max_overflow=5,encoding='utf-8')
Base = declarative_base()

class Product(Base):
    __tablename__ = 'product'
    id = Column(Integer, primary_key=True, autoincrement=True)    #主键，自增
    title = Column(String(255))
    leixin = Column(String(255))
    cover = Column(String(255))

    def __repr__(self):
        output = "(%d, %s, %s)" % (self.id, self.title, self.cover)
        return output

Base.metadata.create_all(engine)
```

piplines.py文件

```
class MySqlPipeline(object):
    def __init__(self):
        self.engine = create_engine("mysql+pymysql://root:123456@127.0.0.1:3306/yaoqi", max_overflow=5)
        # print("**********yaoqi**********")
        # print(self.engine)
        self.session_maker = sessionmaker(bind=self.engine)
        self.session = None

    def open_spider(self, spider):
        self.session = self.session_maker()

    def process_item(self, item, spider):
        product = Product()
        product.cover = item['cover']
        product.title = item['title']
        product.leixin = item['leixin']

        self.session.add(product)
        self.session.commit()  # 不要忘了commit

        return item

    def close_spider(self, spider):
        self.session.close()
```

### 使用redis

settings.py文件

```
SCHEDULER = 'scrapy_redis.scheduler.Scheduler'
DUPEFILTER_CLASS = 'scrapy_redis.dupefilter.RFPDupeFilter'
REDIS_URL = 'redis://@127.0.0.1:6379'
```

