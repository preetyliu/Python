###  从数据库导出excel


存入缓存中的二进制文件需要用getvalue()方法读取
```
f = BytesIO()
f.getvalue()
```
这个例子因为数据太多，分为了多个sheet，每个sheet存了10000行数据。
Excel一个sheet存的数据行数时有限制的。
.xls是256 * 256=65536行，.xlsx是256 * 256 * 16=1048576行
```
from io import BytesIO, StringIO
from django.db import transaction
from django.shortcuts import render, reverse
import xlwt
import xlrd
# Create your views here.
from app.models import Movie, Movie1, Ratings
from django.http import JsonResponse, HttpResponseRedirect, StreamingHttpResponse, HttpResponse
from django.http import FileResponse

def down_load(request):
    if request.method == 'GET':
        movies = Ratings.objects.all()[:200000]
        counts = len(movies) // 10000 + 1
        wbk = xlwt.Workbook()
        for count in range(counts):
            sheet = wbk.add_sheet('Sheet' + str(count), cell_overwrite_ok=True)
            if count + 1 == counts:
                x = len(movies)
            else:
                x = 10000 * (count + 1)
            c = 0
            for i in range(10000 * count, x):
                list2 = ['num', 'num1', 'num2', 'num3']
                list1 = [movies[i].num, movies[i].num1, movies[i].num2, movies[i].num3]
                list3 = [movies[0].num, movies[0].num1, movies[0].num2, movies[0].num3]
                for j in range(len(list1)):
                    if c == 0:
                        sheet.write(0, j, list2[j])
                    else:
                        sheet.write(1, j, list3[j])
                        sheet.write(c, j, list1[j])
                print(i)
                c += 1
        f = BytesIO()  # 创建内存的二进制缓存
        wbk.save(f)  # 把数据存入创建的二进制缓存中
        response = HttpResponse(f.getvalue())
        # 导出成不同的文件,response['Content-Type']的值时不一样的，可以网上搜索对应的属性值
        response['Content-Type'] = 'application/vnd.ms-excel'
        # 如果文件名是中文，需要把中文转换(用quote函数)
        response['Content-Disposition'] = 'attachment;filename="ratings1.xls"'
        return response
```

### 把Excel中的数据导入数据库

```
def leading(request):
    if request.method == 'POST':

        files = request.FILES.get('file')
        type_excel = files.name.split('.')[1]
        if 'xls' == type_excel:
            wb = xlrd.open_workbook(filename=None, file_contents=files.read())
            table = wb.sheets()[0]
            nrows = table.nrows  # 行数

            with transaction.atomic():
                for i in range(1, nrows):
                    row = table.row_values(i)
                    try:
                        Movie.objects.create(id=row[0], name=row[1], type=row[2])
                        # print(i)
                    except:
                        print(i, '============================')
                        pass
            msg = '添加成功'
            return render(request, 'index.html', {'msg': msg})
```
### 验证码

生成验证码的代码很多，生成不同的验证码，代码也不一样，网上很多，在django中只要把生成验证码的代码写到一个单独的文件，然后在views.py中写一个方法，验证码内容存到session中，把生成的验证码图片保存为二进制文件，最后用getvalue()和HttpResponse返回就行了，页面中在需要显示验证码的img标签的src属性中填入这个验证码的url路由就行了

```
session['code'] = code   # code为随机生成的验证码内容
```

```
from utils.yan_zheng import Picture  

def yan_zheng(request):
    if request.method == 'GET':
        # 配置图片地址
        BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        # static地址
        MEDIA_DIR = os.path.join(BASE_DIR, 'media')
        strings = "abcdefghjkmnpqrstwxyz23456789ABCDEFGHJKLMNPQRSTWXYZ"
        size = (150, 50)
        background = 'white'
        pic = Picture(strings, size, background)
        pic.create_pic()
        pic.create_point(300, (220, 220, 220))
        pic.create_line(15, (220, 220, 220))
        code = pic.create_text(MEDIA_DIR + "/fonts/Arial.ttf", 24, (0, 0, 205), 4, (7, 7))
        pic.opera()
        # pic.img.show()
        image_bytes = BytesIO()
        pic.img.save(image_bytes, format='png')   # jpg不行，要报错
        img_bytes = image_bytes.getvalue()
        return HttpResponse(img_bytes, content_type='image/png')
```

