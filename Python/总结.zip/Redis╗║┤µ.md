settings.py文件的配置

```
# 配置基于Redis的缓存系统
CACHES = {
    'default': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': [
            'redis://120.79.226.39:6379/0',
        ],
        'KEY_PREFIX': 'fangall',
        'OPTIONS': {
            'CLIENT_CLASS': 'django_redis.client.DefaultClient',
            'CONNECTION_POOL_KWARGS': {
                'max_connections': 500,
            },
            'PASSWORD': '123456',
        }
    },
    'page': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': [
            'redis://120.79.226.39:6379/1',
        ],
        'KEY_PREFIX': 'fangall:page',
        'OPTIONS': {
            'CLIENT_CLASS': 'django_redis.client.DefaultClient',
            'CONNECTION_POOL_KWARGS': {
                'max_connections': 1000,
            },
            'PASSWORD': '123456',
        }
    },
    'session': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': [
            'redis://120.79.226.39:6379/2',
        ],
        'KEY_PREFIX': 'fangall:session',
        'TIMEOUT': 1209600,
        'OPTIONS': {
            'CLIENT_CLASS': 'django_redis.client.DefaultClient',
            'CONNECTION_POOL_KWARGS': {
                'max_connections': 1000,
            },
            'PASSWORD': '123456',
        }
    },
    'code': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': [
            'redis://120.79.226.39:6379/3',
        ],
        'KEY_PREFIX': 'fangall:code',
        'OPTIONS': {
            'CLIENT_CLASS': 'django_redis.client.DefaultClient',
            'CONNECTION_POOL_KWARGS': {
                'max_connections': 500,
            },
            'PASSWORD': '123456',
        }
    },
}

# 配置将Session放置在缓存中
SESSION_ENGINE = 'django.contrib.sessions.backends.cache'
SESSION_CACHE_ALIAS = 'session'

# 配置DRF扩展
REST_FRAMEWORK_EXTENSIONS = {
    # 配置默认的缓存超时时间
    'DEFAULT_CACHE_RESPONSE_TIMEOUT': 300,
    # 配置默认使用哪组缓存
    'DEFAULT_USE_CACHE': 'default',
    # 配置默认缓存单个对象的key函数
    'DEFAULT_OBJECT_CACHE_KEY_FUNC': 'rest_framework_extensions.utils.default_object_cache_key_func',
    # 配置默认缓存对象列表的key函数
    'DEFAULT_LIST_CACHE_KEY_FUNC': 	      'rest_framework_extensions.utils.default_list_cache_key_func',
}
```

1、缓存网页数据
```
from django.views.decorators.cache import cache_page
@cache_page(timeout=None) 或 @cache_page(60 * 15) 
def provinces(request):
    pass
    
timeout:缓存时间(none表示永久缓存)
60 * 15:指缓存15分钟
```
2、缓存返回数据

```
from rest_framework_extensions.cache.decorators import cache_response

def customize_cache_key(view_instance, view_method, request, args, kwargs):
    """自定义缓存的key的函数"""
    full_path = request.get_full_path()
    return f'fangall:api:{full_path}'

@cache_response(key_func=customize_cache_key)
def get(self, request, agentid, *args, **kwargs):
    pass
```

3、api接口访问缓存

设置：cache.set("需缓存的键","需缓存的值",有效时间)
获取：cache.get("获取键")
删除：cache.delete（"删除键"）
清空：cache.clear（）

```
from django.core.cache import caches
caches['code'].set(tel, code, nx=True, timeout=60) 

['code']:设置的缓存位置
tel:缓存的键
code：缓存的值
timeout:缓存存放的时间
```

4、模板片段缓存。

```
{%load cache%}

{%cache 60  缓存名字 %}
恭喜哦！成功了
{%endcache%}
```