### Anaconda

启动：source  /home/liuzhilong/.bashrc 或者 source  /home/liuzhilong/anaconda3/bin/activate

### 数据结构

###### 1.队列(queue)

先进先出

##### 2.堆栈(Stack)

先进后出

##### 3.线性表

适合查找

##### 4.链表

适合增删