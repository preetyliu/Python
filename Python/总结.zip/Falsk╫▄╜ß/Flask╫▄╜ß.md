### 1. 安装flask

#### 1.1虚拟环境搭建

```
virtualenv --no-site-packages falskenv

激活windows下虚拟环境
cd Scripts
activate
```

#### 1.2 安装

```
pip install flask
```

### 2.创建flask应用

#### 2.1 基于flask的最小的应用

创建hello.py文件（这样把所有内容都写在运行文件中，这样做不好）

```
from flask import Flask

# 获取flask对象
app = Flask(__name__)

# 路由
@app.route('/')
# 视图函数
def gello_world():
	return 'Hello World'

# 启动项目
if __name__ == '__main__':
    运行：python hello.py
	app.run()
```

#### 2.2 把文件分开写

在flask中，两个文件不能相互导入，如果需要导入，那么写到一个公用文件中，然后从公用文件导入，不然相互导入会报错

创建运行文件manage.py

```
from flask import Flask
from flask_script import Manager
from app.views import blueprint

# 获取flask对象
app = Flask(__name__)

# 第二步：注册蓝图
app.register_blueprint(blueprint=blueprint, url_prefix='/app')

# 使用Manage管理Flask对象（管理app）
manage = Manager(app=app)

# 启动项目,run()
if __name__ == '__main__':
    manage.run()
```

创建视图函数文件

```
from flask import Blueprint, redirect, url_for

# 第一步：初始化蓝图，定义两个参数
blueprint = Blueprint('first', __name__)

# 定义路由，绑定视图函数(这样写地址是http://127.0.0.1:8001/app/)
@blueprint.route('/')
def hello():
    return 'Hello World'

# 反向解析
# 地址是http://127.0.0.1:8001/app/redirect/
@blueprint.route('redirect/')
def index():
    # url_for(蓝图第一个参数.视图名)==> 跳转到视图函数hello()
    return redirect(url_for('first.hello'))
```
```<string:s_name>``` :给这个视图函数传一个参数，指定参数类型为字符串
```<s_name>```:这个和上面是一样的，不指定参数类型，那么默认获取的就是字符串类型
```<int:age>```:指定给视图函数传递的参数为整数
```<float:age>```:指定给视图函数传递的参数为浮点型
获取path后面的全部url地址（http://127.0.0.2:8001/app/path/wrwaf/efeaggse/egs/,获取到的是：wrwaf/efeaggse/egs）
uuid的参数只支持uuid值(uuid值：f557e14d-f625-46dc-a8c4-dea3303fed2c)
```
#给路由添加参数（地址是：http://127.0.0.1:8001/app/name/XXX/ ; XXX:传递的参数）
@blueprint.route('name/<string:s_name>/')
def get_name(s_name):
    return '姓名：%s' % s_name
    =================================
@blueprint.route('/path/<path:s_path>/')
def get_path(s_path):
    return '路径为：%s' % s_path
    ==================================
@blueprint.route('/uuid1/<uuid:s_uuid>/')
def get_uuid1(s_uuid):
    return '获取到的值: %s' % s_uuid
```

### 请求与响应

请求是客户端传到服务端； 响应是服务端返回给客户端的，比如设置cookie值
如果是GET请求，获取GET请求中的参数使用request.args
如果是POST/PUT/PATCH/DELETE请求，获取POST请求中的参数使用request.form
获取key重复的value值(有多个相同名字的key)，使用request.form.getlist(key)

```
@blueprint.route('/request/', methods=['GET', 'POST', 'PUT', 'PATCH', 'DELETE'])
def get_request():
    request
    return '111'
    ====================================
    @blueprint.route('/response/', methods=['GET'])
def get_response():
    # make_response: 创建响应，返给页面
    res = make_response('<h2>我是响应</h2>', 200)
    return res
    # 也可以这样写
    # return 'hello',200
```

### 异常

```
@blueprint.route('/error/', methods=['GET'])
def get_error():
    a = 0
    b = 9
    try:
        c = b/a   # (除数不能为0)
    except:
        # 抛出异常
        abort(500)
    return '%s/%s=%s' % (b, a, c)
=========================================
# 接收抛出的异常
@blueprint.errorhandler(500)
def handler_500(exception):
    return '异常信息：%s' % exception
```

### cookie

```
# 添加cookie
@blueprint.route('/cookies/', methods=['GET'])
def get_cookies():
    response = make_response('<h1>hello</h1>', 200)
    # set_cookie中参数，key， value， max_age/expires
    response.set_cookie('session_id', '123456789', max_age=10000)
    return response
===================================================
# 删除cookie
@blueprint.route('/delcookie/', methods=['GET'])
def def_cookie():
    reponse = make_response('<h1>删除cookie</h1>', 200)
    # 第一种
    # reponse.delete_cookie('session_id')

    # 第二种
    reponse.set_cookie('session_id', '12', max_age=0)
    return reponse
```
### session

使用session存数据一般用：redis、memachaed、filesystem

配置redis：

```
# 指定redis作为缓存数据库
app.config['SESSION_TYPE'] = 'redis'
# 指定访问哪一个redis，ip,端口
app.config['SESSION_REDIS'] = redis.Redis(host='127.0.0.1', port=6379)

# 加载app
# 第一种方式
se = Session()
se.init_app(app=app)
# 第二种方式
# Session(app=app)
```

render_template：跳转页面，传递参数直接在后面加

    return render_template('login.html', goods=goods, scores=scores, cotent_h2=cotent_h2)

```
@blue.route('/cart/', methods=['GET', 'POST'])
def cart():
    if request.method == 'GET':
        #拿到session中的goods_name的值
        goods_name = session.get('goods_name')
        return render_template('index.html', goods_name=goods_name)
    if request.method == 'POST':
        # 拿到需要存到redis中的id值
        goods_id = request.form.get('goods_id')
        # 设置session值
        session['goods_id'] = goods_id
        session['goods_name'] = 'MAC'
        session['login'] = False

        # 删除session值
        session.pop('goods_id')
        # 清空session
        session.clear()

        return redirect(url_for('app.cart'))
```

### 模板

挖坑填坑和django中一样

```
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>
        {% block title %}
        {% endblock %}
    </title>
        {% block fcss %}
        {% endblock %}
        {% block fjs %}
        {% endblock %}

</head>
<body>
    {% block content %}
    {% endblock %}
</body>
</html>
```

继承也一样

   {% extends 'base.html' %}

可以用macro声明函数。声明函数之后需要调用调用函数要加两个{{}}

```
{% macro hello(name) %}
    <p>{{ name }}</p>  # 函数的内容
{% endmacro %}
{{ hello('小明') }}  # 调用函数hello()
```

for循环

```
{% macro show_goods(id, name, price, kucun) %}
    商品id： {{ id }}
    商品名称： {{ name }}
    商品价格： {{ price }}
    商品库存： {{ kucun }}
{% endmacro %}
{% for good in goods %}
    {{ show_goods(good.0, good.1, good.2, good.3) }}
{% endfor %}
```

for循环中循环次数用的是：loop

```
{{ loop.index }} # 从1开始计数
{{ loop.revindex }} # 倒着计数，从最大的数字开始到1
{{ loop.index0 }} # 从0开始
{{ loop.first }} # 循环第一次
{{ loop.last }} # 循环最后一次
```

可以把声明的函数写到一个专门的文件中，在页面中只需要导入函数，然后调用函数就行了

```
{% from 'function.html' import hello, show_goods %} # 导入函数
{{ hello('小明') }}
{{ show_goods(good.0, good.1, good.2, good.3) }}
```

过滤器（与django中一样）：|

```
capitalize 单词首字母大写
lower 单词变为小写
upper 单词变为大写
title
trim 去掉字符串的前后的空格
reverse 单词反转
format
striptags 渲染之前，将值中标签去掉
safe 讲样式渲染到页面中
default
last 最后一个字母
first
length 计算长度
sum
sort
```

过滤器还可以几个一起用

```
{{ cotent_h2|trim|length }}
```
### 数据库

#### 创建一个模型文件models.py，在模型文件中定义模型

```
from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()
class Studnet(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    s_name = db.Column(db.String(10), unique=True)
    age = db.Column(db.Integer, default=15)
    __tablename__ = 'student' # 确定表名，可写可不写
    # 定义一个保存数据的方法（这样在保存数据时用着方便，不然每次都要写下面两个）
    def save(self):
        db.session.add(self)
        db.session.commit()
```

#### 在manage.py文件（执行文件）中配置数据库

```
from app.models import db
# 数据库配置
# dialect+driver://username:password@host:port/database
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:123456@127.0.0.1:3306/flask'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# 绑定sqlalchemy和app
db.init_app(app)
```

#### 在views.py文件中进行表中数据的操作

##### 创建表

```
from app.models import db, Studnet
@blu.route('create_db/')
def create_db():
    # 创建数据库中的表
    db.create_all()
    return '创建数据表成功'
```

##### 删除表

```
@blu.route('del_db/')
def del_db():
    # 删除数据库中所有的表
    db.drop_all()
    return '删除数据表成功'
```

##### 添加表中的数据

```
@blu.route('create_stu/')
def create_stu():
    # 创建学生信息
    stu = Studnet()
    stu.s_name = '大傻'
    stu.age = 20
    # 保存数据
    # 第一种  （# 事务： 完整、一致、持久、原子）
    # db.session.add(stu)
    # db.session.commit()
    ====
    # 第二种 : 在模型中定义一个保存的save()方法
    stu.save()
    return '创建学生信息成功'
```

##### 查询表中的数据

条件查询时（filter()）:后面不用.all()，页面中循环后渲染也可以拿到数据，但是后台是一个BaseQuery objects对象，不能直接.属性来获取属性值，需要.all()或者.first()之后拿到一个列表,然后再.属性才能拿到属性值)

获取查询集

```
filter(类名.属性名.运算符(‘xxx’))

filter(类名.属性 数学运算符  值)

```

运算符：

```
contains： 包含
startswith：以什么开始
endswith：以什么结束
in_：在范围内
like：模糊
__gt__: 大于
__ge__：大于等于
__lt__：小于
__le__：小于等于

```

筛选：

```
offset(num)  # 偏移量,跳过几个
limit(num)  # 可以和offset一起使用取一个范围内的数据：...offset(num).limit(num)
order_by('属性名'=>降序：'-属性名')  # 还可以写desc=>降序，默认升序
get(num=>id值)
first()
paginate(num=>获得当前页数, num=>每页显示几个, 布尔值=>是否抛出异常)   # 分页显示
```

逻辑运算：

```
与
	and_
	filter(and_(条件,条件...))
	或者直接filter(条件,条件...)
或
	or_
	filter(or_(条件,条件...))
非
	not_
	filter(not_(条件),not_(条件)…)
```

例子

```
@blu.route('find_stu/')
def find_stu():
    # 查询所有
    stus = Studnet.query.all()
    # 查询id=1的学生信息
    # 第一种方法
    stus = Studnet.query.filter(Studnet.id == 1).all()
    # 第二种方法
    stus = Studnet.query.filter_by(id=1).first()
    return render_template('stu.html', stus=stus)
    # 第三种方法
    sql = 'select * from student where id=1'
    stus = db.session.execute(sql)

    # 模糊查询,查询姓名中包含花的学生信息
    # 语法：filter（模型名.属性.运算符('xx')）
    stus = Studnet.query.filter(Studnet.s_name.contains('花'))
    stus = Studnet.query.filter(Studnet.s_name.startswith('大'))
    # 查询年龄大于等于21的学生
    stus = Studnet.query.filter(Studnet.age.__ge__(21)).all()
    # 查询id在10到13之间的学生
    stus = Studnet.query.filter(Studnet.id.in_([11, 12])).all()
    # 使用like模糊查询姓名中第二位为傻的学生(like'_花%'：'_花'表示花前面只有一位)
    stus = Studnet.query.filter(Studnet.s_name.like('_傻%'))
    # 按照id降序 (order_by)
    stus = Studnet.query.order_by('id')  # 升序
    stus = Studnet.query.order_by('-id')  # 降序

    # 查询数据，获取第五个到第十个的数据
    stus = Studnet.query.all()[4: 10]
    stus = Studnet.query.offset(4).limit(6)
    # 使用get，获取id=5的学生信息
    stus = Studnet.query.get(5)

    # and_, not_, or_(需要导入)
    stus = Studnet.query.filter(Studnet.s_name.like('_傻%'), Studnet.age == 20)  # 并且条件
    stus = Studnet.query.filter(and_(Studnet.s_name.like('_傻%'), Studnet.age == 20))  # 并且条件 and_
    stus = Studnet.query.filter(or_(Studnet.s_name.like('_傻%'), Studnet.age == 20))  # 或条件 or_
    stus = Studnet.query.filter(not_(Studnet.s_name.like('_傻%')), not_(Studnet.age == 20))  # 非条件 not_
```

#### 删除表中数据

```
@blu.route('del_stu/<int:id>/', methods=['GET'])
def del_stu(id):
    if request.method == 'GET':
        stu = Studnet.query.filter(Studnet.id==id).first()
        # 删除学生
        db.session.delete(stu)
        db.session.commit()
        return '删除学生成功'
```

#### 编辑学生

```
@blu.route('up_stu/<int:id>/', methods=['GET', 'post'])
def up_stu(id):
    if request.method == 'GET':
        stu = Studnet.query.filter_by(id=id).first()
        return render_template('edit.html', stu=stu)
    if request.method == 'POST':
        name = request.form.get('name')
        age = request.form.get('age')
        # 第一种
        # stu = Studnet.query.filter(Studnet.id == id).first()
        # stu.s_name = name
        # stu.age = age
        # stu.save()   # 模型中定义了保存的save()方法
        # 第二种
        Studnet.query.filter_by(id=id).update({'s_name': name, 'age': age})
        db.session.commit()
        return redirect(url_for('app.find_stu'))
```

#### 批量添加(第一种)

```
@blu.route('create_many_stu/', methods=['GET'])
def create_many_stu():
    if request.method == 'GET':
        # 批量添加学生信息
        # stus = [['小花', 20], ['小方', 25], ['张三', 16]]
        # for stu in stus:
        #     stu1 = Studnet()
        #     stu1.s_name = stu[0]
        #     stu1.age = stu[1]
        #     stu1.save()
        stus = []
        for _ in range(10):
            stu = Studnet()
            stu.s_name = '大哥%s' % random.randint(1, 1000)
            stu.age = 20
            stus.append(stu)
        db.session.add_all(stus)
        db.session.commit()
        return redirect(url_for('app.find_stu'))
```

#### 批量添加(第二种)
在模型中初始化（定义了 _ _ init _ _ 方法）后再批量添加（对象名=模型名(属性1， 属性2)）

```
@blu.route('create_many_stu1/', methods=['GET'])
def create_many_stu1():
    if request.method == 'GET':
        stus = []
        for _ in range(10):
            stu = Studnet('小弟%s' % random.randint(1, 1000), random.randint(1, 80))
            stus.append(stu)
        db.session.add_all(stus)
        db.session.commit()
        return redirect(url_for('app.find_stu'))
```

#### 分页

```
@blu.route('paginate/', methods=['GET'])
def paginate():
    # 第一种:offset+limit
    page = int(request.args.get('page', 1))
    stus = Studnet.query.offset((page-1) * 5).limit(5)
    # 第二种：切片
    stus = Studnet.query.all()[(page-1) * 5:page * 5]
    # 第三种：paginate
    paginate = Studnet.query.paginate(page, 5)
    stus = paginate.items
    return render_template('stu.html', stus=stus)
```

### 数据库迁移migrate

安装Flask-Migrate插件

```
(venv) $ pip install flask-migrate
```

manage.py(执行文件)中：

```
from flask_migrate import Migrate,MigrateCommand
from models import User,Questions,Answer  # 导入所有的模型
# 下面的都写在manager = Manager(app)下面 
migrate = Migrate(app,db)
manager.add_command('db',MigrateCommand)
```

步骤

```
(venv) $ python manage.py db init  # 初始化
(venv) $ python manage.py db migrate  # 创建迁移脚本
(venv) $ python hello.py db upgrade  # 更新数据库
```

### 一对多关联表

创建一对多模型：relationship在一的那个表，ForeignKey在多的表

```
# 学生
class Studnet(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    s_name = db.Column(db.String(10), unique=True)
    age = db.Column(db.Integer, default=15)
    s_g = db.Column(db.Integer, db.ForeignKey('grade.id'), nullable=True)
    s_sex = db.Column(db.Boolean, default=1)
    tel = db.Column(db.Integer, default=1111111)
    email = db.Column(db.String(20), unique=True)

    __tablename__ = 'student'
==============================================
# 班级
class Grade(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    g_name = db.Column(db.String(20), unique=True)
    student = db.relationship('Studnet', backref='stu', lazy=True)
# lazy: select, dynamic(select:默认为True,直接写lazy=True就行了，查出来是列表；lazy=dynamic,查出来是BaseQuery对象)
```

#### 一对多增删改查

添加班级和学生信息关联关系

```
@blu.route('create_relation/')
def create_relation():
    grades = Grade.query.all()
    gradeids = [grade.id for grade in grades]
    stus = Studnet.query.all()
    for stu in stus:
        stu.s_g = gradeids[random.randint(0, 3)]
        db.session.add(stu)
        db.session.commit()
    return '创建成功'
```

通过学生查班级：查询的结果是一个对象

```
@blu.route('sel_gra_stu/', methods=['GET'])
def sel_gra_stu():
    # 获取id=10的学生信息
    stu = Studnet.query.get(10)
    # 使用关联关系,relationship中的backref属性去反向查询班级
    grade = stu.stu
    return 'id为10的学生的班级是：%s' % grade.g_name
```

通过班级查询学生:查询的结果是一个列表

```
@blu.route('sel_stu_gra/', methods=['GET'])
def sel_stu_gra():
    # 拿到班级为id=2的对象
    grade = Grade.query.get(2)
    # 通过relationship字段查询学生
    stus = grade.student
    return render_template('stu1.html', stus=stus)
```

#### 多对多关联表

创建多对多模型：relationship在哪个表都行

```
# 学生
class Studnet(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    s_name = db.Column(db.String(10), unique=True)
    age = db.Column(db.Integer, default=15)
    s_g = db.Column(db.Integer, db.ForeignKey('grade.id'), nullable=True)
    s_sex = db.Column(db.Boolean, default=1)
    tel = db.Column(db.Integer, default=1111111)
    email = db.Column(db.String(20), unique=True)
# 中间表：需要自己手动创建
s_c = db.Table('s_c', db.Column('s_id', db.Integer, db.ForeignKey('student.id')),
               db.Column('c_id', db.Integer, db.ForeignKey('course.id')))
# 课程
class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    c_name = db.Column(db.String(20), unique=True)
    student = db.relationship('Studnet', secondary=s_c, backref='cou')
```

添加学生课程：stu.cou是一个列表，实际上就是往列表中添加元素

```
@blu.route('add_course/', methods=['GET'])
def add_course():
    if request.method == 'GET':
        # id=4的学生选择了id=1,2,3的三门课程
        stu = Studnet.query.get(4)
        cou1 = Course.query.get(1)
        stu.cou.append(cou1)
        db.session.add(stu)
        db.session.commit()
        return '添加成功'
```

删除学生的课程:stu.cou是一个列表，实际上就是删除列表中的元素

```
@blu.route('del_course/', methods=['GET'])
def del_course():
    if request.method == 'GET':
        # id=4的学生选择了id=1,2,3的三门课程
        stu = Studnet.query.get(4)
        cou1 = Course.query.get(1)
        # 第一种
        stu.cou.remove(cou1)
        # 第二种
        stu.cou.pop(0)
        # 第三种
        del stu.cou[0]
        db.session.add(stu)
        db.session.commit()
        return '删除成功'
```

### 调试

manage.py(执行文件中)：

```
from flask_debugtoolbar import DebugToolbarExtension
# 设置debug为True
app.debug = True
# 绑定toolbar和app
toolbar = DebugToolbarExtension()
toolbar.init_app(app)
```

### restful

创建utils文件夹，放公用文件,创建 _ _ init _ _ .py 文件，在文件中写入：

```
from flask_restful import Api
api = Api()
```

manage.py(执行文件中)：

```
from utils import api
# 绑定api和app
api.init_app(app)
```

在views.py文件中

```
from utils import api
class StudentResource(Resource):
    def get(self, id):
        stu = Studnet.query.filter(Studnet.id == id)
        return {'s_name': stu.s_name}
    def post(self, id):
        pass
    def put(self, id):
        pass
    def patch(self, id):
        pass
    def delete(self, id):
        pass
api.add_resource(StudentResource, '/api/student/<int:id>/')
```