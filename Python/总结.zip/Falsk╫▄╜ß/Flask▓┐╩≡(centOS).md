## Flask部署(centOS)

#### 配置：

2.1.安全组中端口是否开放

#### Nginx

1、nginx的配置conf文件位置：/etc/nginx/nginx.conf

2、nginx的启动、暂停重启、查看状态

```
systemctl start nginx   # 启动nginx
systemctl restart nginx   # 重启nginx
systemctl stop nginx   # 暂停nginx
systemctl status nginx   # 查看nginx状态
```

