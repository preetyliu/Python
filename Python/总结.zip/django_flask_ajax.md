###  djang和flask前后分离

django和flask做项目前后分离时，要返回数据给前端，那么要返回json格式的数据，而在后台查找的结果是对象，是不能以json格式返回的，所以再返回数据时我们需要把查询的对象的属性取出来之后再返回

###### 1、把查询得到的对象遍历，然后把需要传给前端的属性值以列表中套元祖的形式作为值传给前端，前端解析只需要通过下标就可以拿到值

这样写在每次返回值得时候都要写很多属性，有点麻烦，如果返回值不多的话也差不多

以django为例，Flask也可以这样用
```
def new_msg(request):
    if request.method == 'GET':
        book_tuis1 = Book.objects.filter(is_del=0, is_tui=1)
        book_tuis = [(book.id, book.b_name) for book in book_tuis1]
        data = {'code': 200, 'book_ts': book_ts, 'book_tuis': book_tuis}
        return JsonResponse(data)
```

###### 2、在model对象中写一个方法，把model中的所有属性写成字典的形式，最后返回值得时候以列表中套字典的形式作为值返给前端，前端只需要通过列表的下标和.属性名就可以拿到值

这样写在写方法的时候就要方便一些

在模型中(以Flask为例，django也可以这样用)
```
class Facility(BaseModel, db.Model):
    id = db.Column(db.Integer, primary_key=True)  # 设施编号
    name = db.Column(db.String(32), nullable=False)  # 设施名字
    css = db.Column(db.String(30), nullable=True)  # 设施展示的图标

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'css': self.css
        }
```

在views文件中

```
houses = House.query.filter(House.index_image_url != '').order_by('id')[:3]
houses_info = [house.to_dict() for house in houses]
return jsonify(code=status_code.OK, username=username, houses_info=houses_info)
```