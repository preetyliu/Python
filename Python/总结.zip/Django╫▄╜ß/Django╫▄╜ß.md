#### 什么是MVC模式

MVC全名是Model View Controller，是模型(model)－视图(view)－控制器(controller)的缩写，一种软件设计典范，用一种业务逻辑、数据、界面显示分离的方法组织代码，将业务逻辑聚集到一个部件里面，在改进和个性化定制界面及用户交互的同时，不需要重新编写业务逻辑。MVC被独特的发展起来用于映射传统的输入、处理和输出功能在一个逻辑的图形化用户界面的结构中。 **通俗的来讲就是，强制性的使应用程序的输入，处理和输出分开。**

MVC(Model, View, Controller) Model: 即数据存取层。用于封装于应用程序的业务逻辑相关的数据，以及对数据的处理。说白了就是模型对象负责在数据库中存取数据

View: 即表现层。负责数据的显示和呈现。渲染的html页面给用户，或者返回数据给用户。

Controller: 即业务逻辑层。负责从用户端收集用户的输入，进行业务逻辑处理，包括向模型中发送数据，进行CRUD操作

#### Django的模式简介

###### MVT模式

严格来说，Django的模式应该是MVT模式，本质上和MVC没什么区别，也是各组件之间为了保持松耦合关系，只是定义上有些许不同。

Model： 负责业务与数据库(ORM)的对象

View： 负责业务逻辑并适当调用Model和Template

Template: 负责把页面渲染展示给用户

注意： Django中还有一个url分发器，也叫作路由。主要用于将url请求发送给不同的View处理，View在进行相关的业务逻辑处理。

#### 特点：解耦

### VIRTUALENV虚拟环境

#### Windows安装虚拟环境

```
pip install  virtualenv
```

创建虚拟环境

```
virtualenv -p 安装的python路径 --no-site-package venv(文件夹名)
如果电脑中只有一个版本的python，可以不用写-p 和python路径，直接写：virtualenv --no-site-package venv(文件夹名)
```

进入虚拟环境：Scripts目录下执行`activate`

退出虚拟环境：`deactivate`

#### Ubuntu安装虚拟环境

```
apt-get install python-virtualenv
```

创建包含python3版本的虚拟环境

```
virtualenv -p /usr/bin/python3 env
```

进入虚拟环境：`source env/bin/activate`

退出虚拟环境：`deactivate`

### Django使用

#### 安装Django和pyMySQL

```
pip install Django==1.11
或者创建一个记录安装包文件，requeirment.text
pip install -r requeirment.text

pip install PyMySQL
```

#### 创建项目

```
django-admin startproject 项目名
```



manage.py： 是Django用于管理本项目的管理集工具，之后站点运行，数据库自动生成，数据表的修改等都是通过该文件完成

\__init__.py： 指明该目录结构是一个python包，初始化一些工具会使用到

seetings.py： Django项目的配置文件，其中定义了本项目的引用组件，项目名，数据库，静态资源，调试模式，域名限制等

urls.py：项目的URL路由映射，实现客户端请求url由哪个模块进行响应。

wsgi.py：定义WSGI接口信息，通常本文件生成后无需改动



#### 运行Django项目

```
python manage.py runserver 端口
```

#### 创建APP

```
python manage.py startapp APP名
```



## 数据库

#### 数据库关联

`setting.py`文件设置

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'django01',
        'USER': 'root',
        'PASSWORD': 'aini20',
        'HOST': '127.0.0.1',
        'PORT': 3306
    }
}
```

在`__init__.py`导入`pymysql`

```python
import pymysql
pymysql.install_as_MySQLdb()
```

####第一次数据库迁移

```
python manage.py migrate
```

#### 创建admin后台的用户和密码

```
python manage.py createsuperuser
```

#### 后面再次迁移

    python manage.py makemigrations
    python manage.py migrate

#### 进入django后台管理登录页面

    http://127.0.0.1:8081/admin/

#### 运行的配置文件

设置配置文件后可以直接运行程序和查看Django的视图地址等，没必要在查看的时候输入：python  manage.py  runserver
name：随便写
Script path :设置工程文件manage.py文件的路径
Parameters：runserver (后面可以重新设置IP和端口号，新的IP和端口号加在后面就行)

![](E:\Python资料\python作业\总结\Django总结\配置文件.png)


#### urls映射

在app文件夹里创建一个urls.py文件，在这个urls文件中调用app文件夹中的views.py文件中的方法

    from django.conf.urls import url
    from app import views
    urlpatterns = [
        url(r'hellWorld/', views.hello),
        # 查询所有的学生信息
        url(r'selStudent/', views.selStu),
        # 查询age=16的学生信息
        url(r'filStu', views.filterStu),
    ]
再在工程文件夹中的urls.py文件中调用app文件夹中的urls.py文件

    from django.conf.urls import url, inclube
    from django.contrib import admin
    urlpatterns = [
        url(r'^admin/', admin.site.urls),
        url(r'app/', include('app.urls')),
    ]

#### 创建表

设置对应关系的字段为保护模式 :
​    models.CASCADE                      默认值
​    models.PROTECT	                保护模式
​    models.SET_NULL                 置空模式
​    models.SET_DETAULT          置默认值
​    models.SET()     删除的时候重新动态指向一个实体访问对象元素
​    on_delete = models.PROTECT

修改on_delete参数
​    models.OneToOneField('Student', on_delete=models.SET_NULL, null=True)

在删除student对象的时候，stuinfo的关联字段会设置为空null=True，如下命令去删除student的数据：
```
Student.objects.filter(id=1).delete()
```

在models.py文件中创建：
如果没有命名(db_table)，名字就会是：app文件名 _ 类名

    from django.db import models
    class Student(models.Model):
        # 创建表内容和属性
        s_name = models.CharField(max_length=10, unique=True)
        s_age = models.IntegerField(default=16)
        s_sex = models.BooleanField(default=1)
        # 创建表名称
        class Meta:
            db_table = 'student'

在models.py文件中写完创建表的代码后，执行以下命令在migrationgs文件夹中创建一个迁移文件：

    python manage.py makemigrations

表迁移成功后，在执行以下命令执行迁移文件：

    python manage.py migrate

通过数据库中的表，自动创建model模型(在把数据库连接设置弄好后执行下面命令)
注意：
１、模型名可以改，但是要将关联的地方一并修改(重构－重命名)，表名不能改。
２、如果要修改属性名，那么要修改对应的db_clumn属性以便跟列保持对应关系
３、如果希望Django框架来管理模型，需要将manage=False删除或修改为True
```
python manage.py inspectdb
python manage.py inspectdb > app/models.py
```

#### 查询表中的学生信息
查询的结果是一个列表，列表中装的是对象。如果查询的结果有多个，那么可以用遍历的方式分别显示这些对象；如果查询的结果是一个，那么要区分这个对象是可遍历对象还是不可遍历对象，如果是queryset对象可以用遍历对象拿到属性，也可以用直接取下标0再.对象的属性值拿属性；如果是具体对象，那么可以直接.对象的属性拿属性值。
可遍历对象：

    stu = Student.objects.filter(s_age=16)
    return HttpResponse(stu[0].s_name)

不可遍历对象：

    stus = Student.objects.all().order_by('-id').first()
    return HttpResponse(stus.s_name)

查询方式：

    from django.http import HttpResponse
    from app.models import Student
    from django.db.models import Q
    def filterStu(request):
        if request.method == 'GET':

查询年龄等于16的学生,filter()；获取不到数据是返回空

    stu = Student.objects.filter(s_age=16)
    # return HttpResponse(stu[0].s_name)

用get查询id=1的学生,得到的是一个对象，不能遍历，并且获取不到数据会直接报错,id也可以用pk代替；用get只能返回一个数据，返回多个会报错

    stu = Student.objects.get(id=1)

查询年龄不等于16的学生,exclude()

    stu = Student.objects.exclude(s_age=16)

获取所有学的中第一个学生(按照id降序)：order_by=>降序=>  -属性

    stus = Student.objects.all().order_by('-id').first()

获取所有学的中最后一个学生(按照id降序)：order_by=>升序=>  属性

    stus = Student.objects.all().order_by('-id').last()

模糊查询姓名中包含小的信息：contains=>大小写敏感，icontains=>大小写不敏感

    stus = Student.objects.filter(s_name__contains='小')

模糊查询姓名中以小开始的信息：startswith

    stus = Student.objects.filter(s_name__startswith='小')

模糊查询姓名中以小结束的信息: endswith

    stus = Student.objects.filter(s_name__endswith='小')

gt:大于 gte：大于等于 lt：小于 lte：小于等于

    stus = Student.objects.filter(s_age__gt=18)
    stus = Student.objects.filter(s_age__gte=18)

查询id=1,2的学生信息：属性 _ _ in=[等于的所有值]=>列表

    stus = Student.objects.filter(id__in=[1,2])

查询姓名中包含小，并且年龄大于16的信息：且，条件用逗号隔开

    stus = Student.objects.filter(s_name__contains='小', s_age__gt=16)

按id排序(降序:-id; 升序:id)

    stus = Student.objects.all().order_by('-id')

values:返回的值以字典形式显示所有的属性

    stus = Student.objects.all().values()
    return HttpResponse(stus)

列表推导式[i for i in xxx]

    stu_list = [stu1.to_dict() for stu1 in stus]
    return HttpResponse(stu_list)

查询语文成绩最大的学生信息
Max()方法查询后得到的是一个字典对象，可以直接通过 "字典[key]"拿到最大值；max=Max('')，这样写的作用是在查询后得到的字典中把key的名字改为max

    # max = Student.objects.all().aggregate(max=Max('s_chinese'))
    # stus = Student.objects.filter(s_chinese=[max][0]['max']).values()
    # return HttpResponse(stus)
    ===================
    stus =Student.objects.all().values().order_by('s_chinese').first()
    return HttpResponse([stus])

查询比id=1的学生与成绩大10分的学生的信息

    s_ch_1 = Student.objects.filter(id=1).values()
    stus=Student.objects.filter(s_chinese__gt=s_ch_1[0]['s_chinese']+10).values()
    return HttpResponse(stus)

查询语文成绩大于60或者年龄小于20的学生信息
Q()：条件之间可以用与或非的条件（或：| ;     非：~Q()  ;    与：& ）

    stus = Student.objects.filter(Q(s_chinese__gt=60) | Q(s_age__lt=20)).values()
    return HttpResponse(stus)

查询语文成绩比数学成绩大10分的学生信息
F()：可以将模型的两个字段进行算术计算

    stu = Student.objects.filter(s_chinese__gt=F('s_math')+10).values()
    return HttpResponse(stu)

查询语文成绩不等于70或年龄不小于17的学生信息

    stu = Student.objects.filter(~Q(s_chinese=70)|Q(s_age__lt=17)).values()
    return HttpResponse(stu)

#### 添加数据
把添加的数据保存到数据库中：对象.save()

第一种方法：在函数中声明属性，然后用save()方法添加
​    def addStu(request):
​        if request.method == 'GET':
​            stu = Student()
​            stu.s_name = '大明'
​            stu.s_age = '30'
​            stu.s_chinese = '80'
​            stu.s_math = '50.5'
​            stu.save()

第二种方法：在models文件的类中添加init方法，再views文件的函数中给对象添加属性，然后用save()方法保存

    # 在models文件的类中添加init方法，init方法需要继承
    def __init__(self, s_name, s_age, s_chinese, s_math):
        super(Student,self).__init__()
        self.s_name = s_name
        self.s_age = s_age
        self.s_chinese =s_chinese
        self.s_math = s_math
    ====================
    # 在views文件的函数中给对象添加方法
    def addStu(request):
        if request.method == 'GET':
            stu = Student('小花', 25, 89, 98)
            stu.save()

第三种方法：直接在函数中添加属性

    def addStu(request):
        if request.method == 'GET':
             Student.objects.create(s_name='小刚', s_age=28, s_chinese=56, s_math=89)

#### 删除数据

    def delStu(request):
        if request.method == 'GET':
            stu = Student.objects.filter(id=8)
            stu.delete()
            return HttpResponse('删除成功')

#### 修改数据
修改数据时类方法中不能用init方法

    def upStu(request):
        if request.method == 'GET':

修改方法一：

        stu = Student.objects.filter(id=2).first()
        stu.s_name = '小傻'
        stu.save()

修改方法二：

        Student.objects.filter(id=2).update(s_name='小呵')


#### 创建一个一对一关联表
在app文件夹下的models文件中再创建一个类，没有定义表名，所以表名叫：app_studentinfo

    class StudentInfo(models.Model):
        address = models.CharField(max_length=20, null=True)
        tel = models.IntegerField()
        stu = models.OneToOneField(Student)

#### 一对一关联查询

    def oneToOne(request):
        if request.method == 'GET':
查询学生id=2的电话号码和学生地址，还有学生的姓名

    sql写法: select tel,address, s_name from app_studentinfo , student where app_studentinfo.stu_id=student.id and student.id=2;

通过学生对象找一对一关联的表信息(通过学生对象.关联表名；关联表名要全部小写)

    stu = Student.objects.get(id=2)
    stuInfo = stu.studentinfo

通过拓展表找学生信息，知道电话号码：1523523626（通过关联表对象.关联学生表的变量）

    stuInfo = StudentInfo.objects.get(tel=1523523626)
    stu = stuInfo.stu
    return HttpResponse('查询学生的拓展表信息')

#### 创建一对多关联表

    class Grade(models.Model):
        g_name = models.CharField(max_length=10)
        class Meta:
            db_table = 'grade'
    ================================
    class Student(models.Model):
        ......
        g = models.ForeignKey(Grade, on_delete=models.SET_NULL, null=True)
        ......

如果在一对多中外键(ForeignKey)中添加约束：unique=True ，那么一对多就变成一对一了
​    g = models.ForeignKey(Grade, unique=True)

#### 一对多关联查询

    def oneToMany(request):
    if request.method == 'GET':
查询id=4的学生的班级名称

        stu = Student.objects.get(id=4)
        stuGrade = stu.g
        return HttpResponse(stuGrade.g_name)

查询id=1的班级的所有学生

        stu = Grade.objects.get(id=1)
        stude = stu.student_set.all()
        stu_list =[stu1.to_dict() for stu1 in stude]
        return HttpResponse(stu_list)

#### 创建多对多关联表
创建好后，一共会创建三张表，其中多的一张为中间表，表名为：类名 _ 关联变量名

    class Course(models.Model):
        c_name = models.CharField(max_length=10)
        m = models.ManyToManyField(Student, null=True)
        class Meta:
             db_table = 'course'

#### 多对多查询和添加

    def manyToMany(request):
        if request.method == 'GET':
            # 默认id=4的学生添加两门课程(课程id为：1,3)
            stu = Student.objects.get(id=4)
            c1 = Course.objects.get(id=1)
            c3 = Course.objects.get(id=3)
            stu.course_set.add(c1)
            stu.course_set.add(c3)
    ==========================================
            # 删除id=4的学生的课程中的id=3的课程
            stu = Student.objects.get(id=4)
            c1 = Course.objects.get(id=1)
            c3 = Course.objects.get(id=3)
            stu.course_set.remove(c3)
    ==========================================
            # 查询id=4的学生所选课程中id=1课程的名称
            a = stu.course_set.all().filter(id=1).first()
            return HttpResponse(a.c_name)

## 模板(T,渲染页面)

在工程中创建templates文件夹，在文件夹下创建html文件。再在工程文件夹下创建static文件夹，在该文件夹下分别创建css、img、js文件夹

这两个文件夹在工程文件夹下的setting文件中需要修改的配置分别是修改TEMPLATES的属性和添加STATICFILES_DIRS属性

    TEMPLATES = [
        {
            .....
            'DIRS': [os.path.join(BASE_DIR, 'templates')],
            .....
        }
    ]
    =================================
    在文件最后的STATIC_URL = '/static/'属性下添加：
    STATICFILES_DIRS = [
        os.path.join(BASE_DIR, 'static')
    ]

BASE_DIR：这就是地址

#### url映射
在工程文件夹下的urls文件中添加

    from django.conf.urls import url, include
    from django.contrib import admin
    urlpatterns = [
        url(r'^admin/', admin.site.urls),
        url(r'user/', include('app文件名.urls')),
    ]

新建app，添加urls文件

    from django.conf.urls import url
    from app文件夹名 import views
    urlpatterns = [
        url(r'index/', views.函数名),
    ]

#### 添加方法
在新建app文件夹下的views文件中添加方法使html文件的内容渲染到页面(运用render()方法)

    from django.shortcuts import render
    from app.models import Student
    def index(request):
        if request.method == 'GET':
            stus = Student.objects.all()
            return render(request, 'index.html', {'stus': stus})


#### html文件

注释：

    {##}:单行注解都这样写  多行注解：{# comment #} 注解内容 {# endcomment #}；不用<!---->:因为这个如果里面写了标签，运行时还是会读取这里面的内容

#### 引用外部css文件

引用css文件要在head标签中引用
引用css文件方法一：(和html一样，一般不这样用)

    <link rel="stylesheet" href="/static/css/index.css">

引用css文件方法二：(一般这样写)

    {% load static %}   # 引用static
    <link rel="stylesheet" href="{% static 'css/index.css' %}"> 

#### 把数据库查询的内容存入html文件

在body标签中：

    {{stus}}  # 这两个大括号里面的是views文件里render字典中的key

for循环遍历:用于解析数据
for循环语句格式(for循环之后必须要有endfor)：

    {% for循环语句 %} 
        执行内容   
    {% endfor %}

例如：

    {% for stu in stus %}   
        年龄：{{ stu.s_age }}
    {% endfor %}

forloop.counter：从1开始，根据循环次数，每循环一次增加1；如果要让forloop.counter从0开始，就写成：forloop.counter0；如果要forloop.counter倒序就写成：forloop.revcounter

        编号：{{forloop.counter}} 

forloop.first：第一次循环
forloop.last：最后一次循环

解析数据的查询语句格式：{{查询语句}}

        ID:{{stu.id}}

if条件语句：用于判断
if语句格式(可以没有else，if语句最后必须要写endif )：
{% %}：%和{}之间不能用空格，必须相邻

    {% if语句 %} 
        执行内容  
    {% else %} 
        执行内容 
    {% endif %} 

例如：

    {% if forloop.counter == 2 or forloop.counter == 4 %}
        <span style=" color: red ;">姓名：{{stu.s_name}}</span>
    {% endif %}

"|":过滤器，可以通过这个符号改变解析数据的显示模式和数据

全部大写：upper

        姓名：{{stu.s_name|upper}}  # 把姓名全部大写 

和数据查询的语句一样,解析关联数据库和数据库的查询语句一样

        班级：{{stu.g.g_name}}

把在页面中显示的数据中加10 (add)：解析的数据|add:10 (“|”字符之间不能空格)
如果要减10 (add)：解析的数据|add:-10 ；add后面的数字用负数就是减

        语文成绩：{{stu.s_chinese|add:10}}  # 在页面中显示的语文成绩数据中加10分

用百度编辑器，储存的数据是html代码，在页面中显示出来也是html代码，是因为django自动转义了。在页面中要显示出样式，又不显示成html代码，就需要在要显示的数据上加上过滤器safe

    {{stu.msg | safe}}

改变时间的显示模式 (date)：解析的时间|date: '  '

        创建时间：{{stu.creat_time|date:'Y-m-d h:m:s'}} 

#### 继承页面，模板
在templates文件夹下创建一个初始的base.html文件，分别head标签中的title内标签和title标签外以及body标签中挖坑，写如下代码：

    {% block 名字 %}
    {% endblock %}

继承页面：

    {% extends 'base.html' %}

然后在其他html页面中只需要继承通过这个文件的内容，再把要写的内容写到对应的block之间，就可以不需要html页面中的其它内容

    {% extends 'base.html' %}
    {% block title %}
        title中的内容
    {% endblock %}
    {% block extCss %}
        {{ block.super }}
    {% endblock %}
    {% block content %}
        body里的内容
    {% endblock %}

在base中的内容，在其他页面也可以通过{{ block.super }}来继承；在base文件中写入许多页面公共的部分，再通过继承，那么在需要修改的时候就可以只修改base文件中的内容就行了。

#### 拿页面中操作内容的id

在对应页面中操作键对应的url网址为：/app/dStu/?stu_id={{ stu.id }}
问号后面的就是这个操作键对应的id
在views文件的方法中，我们可以通过 “stu_id = request.GET.get('stu_id"   来拿到这个键对应的id值，然后再通过这个对应的id值拿到对应的对象然后进行之后的操作

在工程目录的urls文件中，在url的include参数中添加namespace参数(namspace='名字1 '，相当于命名) 参数，然后给操作完成后要返回的页面的url中添加name参数(name='名字2')，然后通过把“ reverse('名字1：名字2')”参数传给HttpResponseRedirect()，就可以操作完成后跳转，这样写的好处是以后如果需要改动url的命名，只需要改动url，不需要到方法中再去改动

    url(r'user/', include('app文件名.urls', namespace='名字1')),
    url(r'index/', views.函数名, name='名字2'),

request.GET得到的是一个字典
得到页面中的值的时候需要用：request.GET.get('标签name的值')或者request.POST.get('标签name的值')来得到，得到的值是标签的value属性的值
需要提交时，html文件中的标签需要添加' method="post” '属性，才能通过方法得到

    <form action="" method="post">
        <input type="hidden" name="stu_id" value="{{ stu.id }}">
        <p>姓名: <input type="text" name="name" value="{{ stu.s_name }}"> </p>
        <p>年龄：<input type="text" name="age" value="{{ stu.s_age }}" > </p>
        <input type="submit" value="提交">
    </form>

如果是编辑等需要一个新页面的操作，那么我们就需要新建一个对应的html文件，然后在方法中判断method的值，如果是“GET”,就通过render()方法，跳转到这个页面，操作完成后提交请求，
这时在方法中应有对应的method值是“POST”的判断，把操作后的结果更新到数据库中，然后跳转回渲染的页面
render()格式:

    render(request, '页面名字', data(一般用字典的形式) )
    ==============================================
    def update(request):
        if request.method == 'GET':
            stu_id = request.GET.get('stu_id')
            stu = Student.objects.get(id=stu_id)
            return render(request, 'edit.html', {'stu': stu})
        if request.method == 'POST':
            stu_id = request.POST.get('stu_id')
            name = request.POST.get('name')
            age = request.POST.get('age')
            stu = Student.objects.filter(id=int(stu_id)).update(s_name=name, s_age=age)
            return HttpResponseRedirect(reverse('myapp:sel_stu'))  # 使页面跳转回去

跳转页面：HttpResponseRedirect

跳转的URL后面有参数时可以这样写：
``` HttpResponseRedirect(reverse('/myapp/sel_stu/'+ 参数变量 + '/' +参数变量 + '/')) ```

    from django.http import HttpResponse, HttpResponseRedirect
    def addStuCou(request, id):
        if request.method == 'GET':
            ....
            return render(request, 'crouses.html', {'courses': courses})
        if request.method == 'POST':
            ....
            return HttpResponseRedirect(reverse('myapp:sel_stu'))

url也可以这样写：

    <a href="/app/addStuCou/{{ stu.id }}/">添加课程</a>

这时，views文件中的url映射应该这样写：
(\d+)：这是正则表达式，为了得到路径中的这个{{ stu.id }}参数

    url(r'addStuCou/(\d+)/', views.addStuCou),

方法的写法：方法参数中的“id”就是url映射中的“(\d+)”

    def addStuCou(request, id):
        if request.method == 'GET':
            courses = Course.objects.all()
            return render(request, 'crouses.html', {'courses': courses})
        if request.method == 'POST':
            stu = Student.objects.get(id=id)
            c_id = request.POST.get('c_id')
            c = Course.objects.get(id=int(c_id))
            stu.course_set.add(c)
            return HttpResponseRedirect(reverse('myapp：sel_stu'))

#### django自带后台注册登录

用django的admin添加用户

    python manage.py createsuperuser

登录的时候运用模型，判断提交的账号和密码是否正确

    from django.contrib.auth.decorators import login_required
    from django.shortcuts import render, reverse
    from django.contrib import auth
    from django.http import HttpResponseRedirect
    ====================================
    def login(request):
        if request.method == 'GET':
            return render(request, 'backweb/login.html')
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')
            # 验证用户名和密码
            user = auth.authenticate(request, username=username, password=password)
            # 验证用户成功
            if user:
                auth.login(request, user)
                return HttpResponseRedirect(reverse('backweb:index'))
            # 验证不成功
            else:
                return HttpResponseRedirect(reverse('backweb:login'))

验证账号和密码的正确用的是：auth.authenticate()

    user = auth.authenticate(request, username=username, password=password)

登录主要运用的是：auth.login()

    auth.login(request, user)

退出主要运用的是：auth.logout()

    auth.logout(request)

还可以用UserLoginForm(request.POST)验证账号或密码是否为空

```
form = UserLoginForm(request.POST)
if form.is_valid():
    都有值
else:
    有一个为空
```

在页面中判断哪个为空：

```
{{ form.errors.username }}
{{ form.errors.password }}
```

在退出后，我们应该返回到登录页面，而此时也可以通过网站直接访问后台，所以为了让后台只能通过登录页面登录后访问，就需要给url映射添加login_required()方法

    from django.contrib.auth.decorators import login_required
    url(r'index/', login_required(views.index), name='index'),

form表单在使用时需要会有拦截：需要在表单中写入：{% csrf_token %}，否则会报403错误

#### 分页功能

分页功能主要用的是Paginator模块：

    from django.core.paginator import Paginator

#### 不用django自带后台登录注册

在不用django自带的登录注册系统时，登录除了验证账号密码是否正确，还要在跳转到首页时添加cookie和session值：
> 第一步：在cookie中设值
> 第二步:服务端存cookie中设的值

#### 注意

在页面中如果获取的是多项选框这种一个标签有多个值时，需要用getlist(),因为得到的值是一个列表，如果用get()，拿到的是其中的一个值：

    pers = request.POST.getlist('pers')

#### 中间键

中间键的方法名为“process_request()”,不能改

    def process_request(self, request):

request.user默认为：AnymousUser
记录当前登录系统的用户：

    request.user = user

在任何页面中任何位置可以使用“{{ user }}”去解析当前登录系统的user信息

在中间件中通过用户拿到角色在拿到权限，然后拿到权限名称，然后给user添加属性，再到页面中拿权限的名称列表（all()必须要写）：

    user_pro = [p.p_name for p in user.r_u.r_p.all()]
    user.user_pro = user_pro
    ===============================
    # 在页面判断是否有权限
    {% if 'TISTARTICLE' in user.user_pro %}
    {% endif %}

#### 文件上传

文件上传中的前端页面的form标签必须要有enctype="multipart/form-data"属性，才能接收上传的文件，接收时要用FILES接收

    icon = request.FILES.get('icon')

settings文件配置好后创建media文件夹

    # 配置上传文件地址
    MEDIA_URL = '/media/'
    MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

如果media文件夹不在项目中，那么settings文件的配置应该写成media文件夹的地址

```
MEDIA_URL = '/media/'
MEDIA_ROOT = 'E:\my_workspace\/fresh_shop_media\media'
```

工程目录下的urls文件配置

    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

#### 日志

日志的4个组件：

    loggers：接收日志的入口
    handlers：处理日志，并按照指定的格式保存
    filters：过滤，过滤loggers丢给handlers的日志信息
    formatters：指定格式

日志级别：

    DEBUG < INFO < WARNING < ERROR < CRITICAL

日志文件配置

    # 指定日志文件地址
    LOG_PATH = os.path.join(BASE_DIR, 'log')
    # isdir：判断是否是否为文件夹
    if not os.path.isdir(LOG_PATH):
        os.mkdir(LOG_PATH)
        ==========================
    # 配置日志文件
    LOGGING = {
        'version': 1,
        'disable_existing_loggers': False,
        # 格式化日志
        'formatters': {
            'simple': {
                'format': '%(created)s %(process)d %(message)s'
            },
        },
        # 接收日志信息
        'loggers': {
            'dj': {
                'handlers': ['dj_handlers'],
                'level': 'INFO',
            },
        },
        # 处理日志信息
        'handlers': {
            'dj_handlers': {
                'level': 'INFO',
                # 当日志文件达到一个大小时切割文件
                'class': 'logging.handlers.RotatingFileHandler',
                'filename': '%s/dj.log' % LOG_PATH,
                'formatter': 'simple',
                # 指定切割的文件大小
                'maxBytes': 1024 * 1024 * 5,
            },
        },
    }

#### 前后分离
前后分离，MVT中的T不包含在项目中
VUE(前端) + restframework(后端)
状态转移：

    GET: 查询
    POST: 创建
    PUT: 用于修改（全部变量进行修改）
    PATCH: 用于修改（部分变量进行修改）
    DELETE: 删除

#### 装饰器

AOP,面向切面编程

    def is_login(func):
        def check_user():
            return func()
        return check_user
        =====================================
    @is_login
    def func():
        return

###### restful

要运用restful，首先要在settings.py文件中的INSTALLED_APPS= []属性中添加rest_framework以及在最后添加一些配置:

    INSTALLED_APPS = ['rest_framework',]
    REST_FRAMEWORK = {
        # 重构返回数据结果
        'DEFAULT_RENDERER_CLASSES': (
            'utils.ReturnRenderer.MyJSONRenderer',      # 重构MyJSONRenderer的地址
        ),
        # 分页
        'DEFAULT_PAGINATION_CLASS':      'rest_framework.pagination.PageNumberPagination',
        'PAGE_SIZE': 2,  # 每页显示的数量
        # 配置过滤
        'DEFAULT_FILTER_BACKENDS': ('rest_framework.filters.DjangoFilterBackend', 'rest_framework.filters.SearchFilter'),
}

用rest给数据进行增删改查：
在urls文件中

    from django.conf.urls import url
    from rest_framework.routers import SimpleRouter
    from app import views
    router = SimpleRouter()
    router.register('student', views.StudentSource)

在app文件夹中新建一个文件，用来写一个方法，返回查询结果

    from rest_framework import serializers, mixins
    from app.models import Student
    class StudentSerializer(serializers.ModelSerializer):
    s_name = serializers.CharField(error_messages={'blank':'姓名不能为空'})
    class Meta:
        model = Student
        fields = ['id', 's_name', 's_age']
    # 如果要给输出的结果添加字段
    def to_representation(self, instance):
        # 调用父类，拿到虚拟化结果
        data = super().to_representation(instance)
        # 对序列化结果进行添加参数
        data['address'] = '金科南路'
        return data

在views文件中

    from rest_framework import mixins, viewsets
    from app.app_serializers import StudentSerializer
    class StudentSource(mixins.ListModelMixin, viewsets.GenericViewSet, mixins.RetrieveModelMixin,
                    mixins.CreateModelMixin, mixins.DestroyModelMixin, mixins.UpdateModelMixin):
        # 查询资源的所有数据
        queryset = Student.objects.filter(is_del=False)
        # 序列化
        serializer_class = StudentSerializer
        # 过滤
        第一种方法
        # from app.app_filter import Studentfilter
         # filter_class = Studentfilter
        第二种方法（这种感觉好用些）
        def get_queryset(self):
            queryset = self.queryset
            return queryset
        # 下面可以重写增删改查的方法

过滤是要在app文件夹中创建一个文件用来写过滤的类和方法

    import django_filters
    from rest_framework import filters
    from app.models import Student
    class Studentfilter(filters.FilterSet):
        # 过滤s_name参数，精确过滤(lookup_expr='contains':模糊查询(大小写敏感)；icontains:大小写不敏感)
        s_name = django_filters.CharFilter('s_name', lookup_expr='contains')
        # 过滤年龄
        s_age_min = django_filters.NumberFilter('s_age', lookup_expr='gt')  # 年龄大于多少
        s_age_max = django_filters.NumberFilter('s_age', lookup_expr='lt')  # 年龄小于多少
        class Meta:
            model = Student     # 过滤的模型
            fields = ['s_name']



一般我们进行数据删除时都不是直接删除数据，而是进行软删除：在数据库中添加一个布尔值字段，通过这个字段的值来决定是用还是不用（不用就行当于删除了数据）

重写删除和查询方法，在views文件下的用rest的类下直接写
因为一般用的软删除，所以我们一般也要重写删除的方法：

    # 重写删除，改成软删除
    def perform_destroy(self, instance):
        instance.is_del = True
        instance.save()

我们一般在返回的结果中会显示返回的状态码和返回值的提示信息，一般会用我们自定义的状态码，因此我们一般也要重写查询方法：

>1.在views文件的类中重写查找

    def retrieve(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            serializer = self.get_serializer(instance)
            return Response(serializer.data)
        except:
            data = {
                'code': 1001,
                'msg': '学生不存在',
            }
        return Response(data)

>2.在新建的utils文件夹中，创建一个ReturnRenderer.py文件对返回数据的render方法进行重写

    from rest_framework.renderers import JSONRenderer
    class MyJSONRenderer(JSONRenderer):
        """
        {
            code: 0,
            msg: "请求成功",
            data: data,
        }
        """
        def render(self, data, accepted_media_type=None, renderer_context=None):
            if isinstance(data, dict):
                code = data.pop('code', 0)
                msg = data.pop('msg', '请求成功')
            else:
                code = 0
                msg = '请求成功'
            res = {
                'code': code,
                'msg': msg,
                'data': data,
            }
            return super().render(res, accepted_media_type=None, renderer_context=None)

核心：资源、状态转移、接口统一

    GET  /app/student/
    GET/PUT/PATH/DELETE  /app/student/[id]/
    POST  /app/student/
    ============================================
    $.get(url, function(data){})
    $.post(url, {'key': value}, function(data){})

rest返回结果：状态码，数据，信息

    [
        "data":
        [
            {
                "id": 1,
                "s_name": "张三丰",
                "s_age": 20
            },
            {
                "id": 2,
                "s_name": "张无忌",
                "s_age": 16
            },
        ],
        "code": 200,
        "msg": "请求成功",
    ]

###### ajax

    {% csrf_token %}
    function post_stu(){
           var s_name = $('#s_name').val()
           var s_age = $('#s_age').val()
           var csrf = $('input[name="csrfmiddlewaretoken"]').val()
            $.ajax({
                url: '/app/student/',
                type: 'POST',
                dataType: 'json',
                data: {
                    's_name' : s_name,
                    's_age' : s_age,
                },
                headers: {'X-CSRFToken': csrf},
                success: function(data){
                    alert('提交成功')
                },
                error: function(data){
                    alert('提交失败')
                },
            })
        }
location.search: 取url后面的参数
```
?house_id=10
```
search_url.split('=')[1]: 参数的值

```
10
```


在前端页面中使用下标取需要遍历对象中的值

    list = [对象1, 对象2, 对象3, 对象4]
    {{ list.1.属性 }}  # 取列表list中下标为1的对象的属性

#### 判断是否登录
如果没登录，页面中获取的user对象是有的，获取的user对象为AnonymousUser，但是这个user对象没有任何属性，所以当我们判断是否登录时，可以用user的属性来判断：

    {% if user.id %} # 如果登录了则不为空，如果没登录则为空
    {% endif %}

#### 页面中的数据查询

通过后端传的值查询传递过来的对象的表中的数据：{{对象.属性}}

    {{ food.price }}

通过后端传的值查询传递过来的对象关联的其它的表中的数据（注意：一对多关联查询的后的对象需要遍历或者用first（或者all等方法）之后才能用直接点属性的方法来查询属性值，并且用的first、all等方法不能用方法加括号( first() )，而是直接用方法名( first )，在后端的时候才用方法加括号）：

    {{ food.cartmodel_set.first.c_num }}

### Django原生SQL语句

```
变量名 = 模型名.objects.raw('sql查询语句')
```
或者
```
from django.db import connection
def foo(request):
	try:
		with connection.cursor() as cursor:
			connection.execute('原生SQL语句')
			connection.commit()
	except 异常名:
		connection.rollback()
	finally:
		connection.close()
```
